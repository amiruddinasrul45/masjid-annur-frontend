/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Users, Search, User, Calendar, CreditCard, Award, ShieldCheck, ArrowUpRight, DollarSign, Plus, Check, MapPin, Download, LogOut, ChevronRight, CornerDownRight, BellRing, ChevronLeft, X, Receipt } from 'lucide-react';
import { Donor, Allocation, Disbursement, DonationRecord } from '../types';

interface TransparencyTabProps {
  donors: Donor[];
  allocations: Allocation[];
  disbursements: Disbursement[];
  totalTarget: number;
  totalCollected: number;
  totalSpent: number;
  onAddDisbursement: (newDisb: Omit<Disbursement, 'id' | 'date' | 'status'>) => void;
  onAddDonorPayment: (donorId: string, paymentRecord: DonationRecord) => void;
}

export const TransparencyTab: React.FC<TransparencyTabProps> = ({
  donors,
  allocations,
  disbursements,
  totalTarget,
  totalCollected,
  totalSpent,
  onAddDisbursement,
  onAddDonorPayment
}) => {
  // Views navigation inside Profil & Transparansi
  const [currentSection, setCurrentSection] = useState<'transparansi' | 'donatur-list' | 'dashboard-khusus'>('donatur-list');
  const [donorSubTab, setDonorSubTab] = useState<'one-time' | 'monthly'>('one-time');
  
  // Specific view sub-selection
  const [selectedDonorProfile, setSelectedDonorProfile] = useState<Donor | null>(null);
  const [personalDashboardDonorId, setPersonalDashboardDonorId] = useState<string | null>(null);
  
  // Selected allocation for custom category/pos detail page
  const [selectedAllocation, setSelectedAllocation] = useState<Allocation | null>(null);

  // Selected disbursement for transaction details modal
  const [selectedDisbursement, setSelectedDisbursement] = useState<Disbursement | null>(null);
  
  // Searching
  const [searchQuery, setSearchQuery] = useState('');

  // Cash flow active sub-view state
  const [activeCashFlowDetail, setActiveCashFlowDetail] = useState<'masuk' | 'keluar' | 'sisa' | null>(null);
  const [cashFlowSearchQuery, setCashFlowSearchQuery] = useState('');

  // Administrative Disbursement Simulation Form state
  const [showAdminDisburse, setShowAdminDisburse] = useState(false);
  const [disburseAmount, setDisburseAmount] = useState(10000000);
  const [disburseRecipient, setDisburseRecipient] = useState('');
  const [disbursePurpose, setDisbursePurpose] = useState('');
  const [disburseCategory, setDisburseCategory] = useState('Kubah & Ornamen');

  const formattedRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(val);
  };

  const formatIndonesianDateTime = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) {
        return dateStr;
      }
      const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
      const months = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
      ];
      
      const dayName = days[d.getDay()];
      const dayDate = d.getDate();
      const monthName = months[d.getMonth()];
      const year = d.getFullYear();
      
      let hours = d.getHours();
      let minutes = d.getMinutes();
      
      if (dateStr.length <= 10) {
        const code = dateStr.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
        hours = 9 + (code % 8);
        minutes = code % 60;
      }
      
      const padZero = (n: number) => String(n).padStart(2, '0');
      
      return `${dayName}, ${dayDate} ${monthName} ${year} pkl. ${padZero(hours)}:${padZero(minutes)} WIB`;
    } catch {
      return dateStr;
    }
  };

  const getInitials = (name: string) => {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0][0].toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase().slice(0, 2);
  };

  const renderInitialsCircle = (name: string, sizeClass: string = "h-9 w-9 text-xs", variant: 'light' | 'dark' = 'light') => {
    const initials = getInitials(name);
    const colors = [
      'bg-emerald-100 text-emerald-800 border-emerald-300',
      'bg-teal-100 text-teal-800 border-teal-300',
      'bg-sage/15 text-deep border-sage/30',
      'bg-amber-100 text-amber-900 border-amber-300',
      'bg-[#FAF9F5] text-deep border-slate-200'
    ];
    let sum = 0;
    for (let i = 0; i < name.length; i++) {
      sum += name.charCodeAt(i);
    }
    const colorClass = variant === 'dark' ? 'bg-white/10 text-cream border-white/20 font-bold' : colors[sum % colors.length];

    return (
      <div className={`${sizeClass} rounded-full border flex items-center justify-center font-extrabold shrink-0 uppercase tracking-tight select-none shadow-[inset_0_2px_4px_rgba(0,0,0,0.06)] ${colorClass}`}>
        {initials}
      </div>
    );
  };

  // Handle simulated disbursement
  const handleAdminDisburseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disburseRecipient || !disbursePurpose) return;

    onAddDisbursement({
      amount: Number(disburseAmount),
      recipient: disburseRecipient,
      purpose: disbursePurpose,
      category: disburseCategory,
      proofInvoice: `INV/OUT/2026/05/${Math.floor(100+Math.random()*900)}`
    });

    // Reset Form
    setDisburseRecipient('');
    setDisbursePurpose('');
    setShowAdminDisburse(false);
  };

  // Handle donor paying next month's invoice inside their Dashboard Khusus
  const handlePayNextMonthInvoice = (donor: Donor) => {
    if (!donor.monthlyCommitment) return;
    const nextMonthNum = (donor.monthsPaid || 0) + 1;
    const isLunas = nextMonthNum >= (donor.totalMonthsCommit || 24);

    const invoiceNum = `INV/MHD/2026/05/${Math.floor(100+Math.random()*900)}`;

    const record: DonationRecord = {
      id: `dh_new_${Date.now()}`,
      amount: donor.monthlyCommitment,
      date: new Date().toISOString().split('T')[0],
      type: 'monthly',
      description: `Iuran Bulanan Masjid An-Nur - Bulan Ke-${nextMonthNum} ${isLunas ? '(LUNAS)' : ''}`,
      invoiceNumber: invoiceNum,
      status: 'sukses'
    };

    onAddDonorPayment(donor.id, record);

    // Refresh profile in active view if selected
    if (selectedDonorProfile?.id === donor.id) {
      const updated = donors.find(d => d.id === donor.id);
      if (updated) setSelectedDonorProfile(updated);
    }
  };

  // Filtered Donors
  const activeMonthlyDonors = donors.filter(d => 
    d.type === 'monthly' && d.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const oneTimeDonorsList = donors.filter(d => 
    d.type === 'one-time' && d.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col">
      {/* Keuangan Dashboard Header */}
      <div className="bg-deep text-white p-4 select-none shrink-0 border-b border-sage/10 flex justify-center items-center">
        {/* Quick select menu with exactly 2 tabs */}
        <div className="flex bg-slate-900/40 p-0.5 rounded-xl border border-white/10 text-[11px] font-bold w-full max-w-[280px]">
          <button
            onClick={() => {
              setCurrentSection('donatur-list');
              setSelectedDonorProfile(null);
              setSelectedAllocation(null);
              setActiveCashFlowDetail(null);
            }}
            className={`flex-1 text-center py-1.5 rounded-lg cursor-pointer transition-colors ${
              currentSection === 'donatur-list' ? 'bg-cream text-deep font-extrabold' : 'text-slate-300 hover:text-white'
            }`}
          >
            Penyumbang
          </button>
          <button
            onClick={() => {
              setCurrentSection('transparansi');
              setSelectedDonorProfile(null);
              setSelectedAllocation(null);
              setActiveCashFlowDetail(null);
            }}
            className={`flex-1 text-center py-1.5 rounded-lg cursor-pointer transition-colors ${
              currentSection === 'transparansi' ? 'bg-cream text-deep font-extrabold' : 'text-slate-300 hover:text-white'
            }`}
          >
            Laporan Keuangan
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 p-4 space-y-4">

        {/* ======================================= */}
        {/* SECTION A: TRANSPARANSI LAPORAN KEUANGAN */}
        {/* ======================================= */}
        {currentSection === 'transparansi' && (
          <div className="space-y-4 animate-fade-in">
            {selectedAllocation ? (
              /* ========================================== */
              /* HALAMAN DETAIL PENGELUARAN POS ALOKASI RAB */
              /* ========================================== */
              <div className="bg-white border border-sage/10 rounded-[32px] p-5 card-shadow space-y-4 animate-fade-in text-left">
                {/* Back Button */}
                <div className="flex justify-between items-center">
                  <button
                    onClick={() => setSelectedAllocation(null)}
                    className="px-3 py-1.5 bg-[#FAF9F5] hover:bg-[#FAF9F5]/70 text-slate-600 border border-slate-200 rounded-xl text-[10px] font-bold cursor-pointer transition-colors flex items-center gap-1"
                  >
                    <ChevronLeft size={12} />
                    Kembali
                  </button>
                  <span className="text-[9px] bg-sage/15 text-deep border border-sage/25 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    Detail Pengeluaran Pos
                  </span>
                </div>

                {/* Allocation pos title header */}
                <div className="space-y-1">
                  <span className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-mono tracking-wide uppercase">
                    Kategori: {selectedAllocation.category}
                  </span>
                  <h3 className="serif font-extrabold text-[13px] text-deep leading-snug mt-1 pt-1">
                    {selectedAllocation.item}
                  </h3>
                  <div className="flex items-center gap-2 mt-1 select-none text-[10px] text-slate-404 font-medium">
                    <span>Status: <strong className="text-olive">{selectedAllocation.status}</strong></span>
                  </div>
                </div>

                <div className="h-px bg-slate-100" />

                {/* Stats comparison cards */}
                <div className="grid grid-cols-2 gap-3 select-none">
                  <div className="bg-[#FAF9F5] p-3 rounded-2xl border border-sage/10">
                    <span className="text-[8px] text-[#A3B18A] uppercase tracking-wider block font-bold leading-none">ESTIMASI RAB POS</span>
                    <strong className="text-xs font-mono text-slate-800 font-black block mt-1.5">
                      {formattedRupiah(selectedAllocation.estimatedCost)}
                    </strong>
                  </div>
                  <div className="bg-[#FAF9F5] p-3 rounded-2xl border border-sage/10">
                    <span className="text-[8px] text-deep uppercase tracking-wider block font-bold leading-none">REALISASI BELANJA</span>
                    <strong className="text-xs font-mono text-deep font-black block mt-1.5">
                      {formattedRupiah(selectedAllocation.actualSpent)}
                    </strong>
                  </div>
                </div>

                {/* Remaining Budget card */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl flex justify-between items-center text-[11px] font-medium text-slate-705">
                  <span>Sisa Sektor Alokasi:</span>
                  <strong className="font-mono text-slate-900 font-bold">
                    {formattedRupiah(selectedAllocation.estimatedCost - selectedAllocation.actualSpent)}
                  </strong>
                </div>

                {/* Budget Absorption progress bar */}
                <div className="space-y-1 my-1">
                  <div className="flex justify-between items-center text-[9px] font-bold text-slate-404 uppercase tracking-widest">
                    <span>Penyerapan Anggaran</span>
                    <span className="font-mono text-deep">
                      {selectedAllocation.estimatedCost > 0 ? ((selectedAllocation.actualSpent / selectedAllocation.estimatedCost) * 100).toFixed(0) : 0}%
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-105 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-deep rounded-full transition-all duration-500"
                      style={{ width: `${selectedAllocation.estimatedCost > 0 ? Math.min((selectedAllocation.actualSpent / selectedAllocation.estimatedCost) * 100, 100) : 0}%` }}
                    />
                  </div>
                </div>

                <div className="h-px bg-slate-100" />

                {/* Disbursements matching this allocation's category */}
                <div className="space-y-2.5">
                  <h4 className="serif font-extrabold text-[10.5px] text-deep uppercase tracking-wider">
                    RINCIAN PEMBAYARAN KATEGORI INI
                  </h4>

                  {disbursements.filter(d => d.category === selectedAllocation.category).length === 0 ? (
                    <div className="text-center py-8 bg-[#FAF9F5] rounded-3xl border border-dashed border-slate-200 text-slate-450 text-xs">
                      Belum ada catatan transaksi pembayaran terdaftar untuk kategori pos ini.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {disbursements.filter(d => d.category === selectedAllocation.category).map((disb) => (
                        <div key={disb.id} className="p-3 bg-slate-50 border border-slate-100 rounded-2xl flex gap-3 text-left">
                          <div className="h-8 w-8 rounded-xl bg-amber-500/10 text-amber-808 flex items-center justify-center font-bold text-sm shrink-0">
                            💸
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-center select-none">
                              <span className="text-[9px] text-slate-404 font-mono font-medium">{disb.date} • {disb.proofInvoice}</span>
                              <span className="text-[8px] bg-sage/20 text-deep font-extrabold px-1.5 py-0.2 rounded uppercase">DIBAYARKAN</span>
                            </div>
                            <h5 className="font-bold text-xs text-slate-800 mt-1">{formattedRupiah(disb.amount)}</h5>
                            <p className="text-[11px] text-slate-600 mt-0.5 leading-normal">
                              Penerima: <strong className="text-slate-800">{disb.recipient}</strong>
                              <span className="block italic text-slate-450 mt-0.5">Keperluan: {disb.purpose}</span>
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : activeCashFlowDetail === 'masuk' ? (
              /* ========================================== */
              /* DETAIL ALIRAN DANA MASUK / PENYUMBANG      */
              /* ========================================== */
              <div className="bg-white border border-sage/10 rounded-[32px] p-5 card-shadow space-y-4 animate-fade-in text-left">
                {/* Back Button */}
                <div className="flex justify-between items-center select-none">
                  <button
                    onClick={() => setActiveCashFlowDetail(null)}
                    className="px-3 py-1.5 bg-[#FAF9F5] hover:bg-[#FAF9F5]/70 text-slate-600 border border-slate-200 rounded-xl text-[10px] font-bold cursor-pointer transition-colors flex items-center gap-1 ml-0.5"
                  >
                    <ChevronLeft size={12} />
                    Kembali
                  </button>
                  <span className="text-[8px] bg-emerald-500/10 text-emerald-700 border border-emerald-300/20 font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                     Aliran Dana Masuk
                  </span>
                </div>

                {/* Info and Search bar */}
                <div className="space-y-1 my-0.5 select-none">
                  <span className="text-[8px] text-slate-404 uppercase tracking-widest font-black block">TOTAL DANA MASUK TERKUMPUL</span>
                  <h3 className="serif font-black text-lg text-emerald-700 leading-none">
                    {formattedRupiah(totalCollected)}
                  </h3>
                  <p className="text-[10px] text-slate-404 font-semibold mt-1">
                    Berikut adalah daftar lengkap seluruh penyumbang kas pembangunan Masjid An-Nur.
                  </p>
                </div>

                {/* Sub Search Box */}
                <div className="relative font-bold">
                  <Search size={15} className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-404 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="CARI NAMA PENYUMBANG MASJID..."
                    value={cashFlowSearchQuery}
                    onChange={(e) => setCashFlowSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-205 focus:border-deep bg-white rounded-2xl text-[9.5px] font-black uppercase text-slate-705 tracking-wider focus:outline-none transition-all shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)] placeholder:text-slate-404"
                  />
                </div>

                <div className="h-px bg-slate-100" />

                {/* Unified searchable donor list */}
                <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                  {(() => {
                    const filteredDonors = donors.filter(d => 
                      d.name.toLowerCase().includes(cashFlowSearchQuery.toLowerCase())
                    );
                    
                    if (filteredDonors.length === 0) {
                      return (
                        <div className="text-center py-10 bg-[#FAF9F5] border border-dashed border-slate-150 rounded-3xl text-xs text-slate-404 select-none font-semibold">
                          Penyumbang dengan nama "{cashFlowSearchQuery}" tidak ditemukan
                        </div>
                      );
                    }

                    return filteredDonors.map((donor) => {
                      const badgeBg = donor.type === 'monthly' ? 'bg-teal-500/10 text-teal-700' : 'bg-amber-500/10 text-amber-700';
                      const badgeLabel = donor.type === 'monthly' ? 'Bulanan' : 'Sekali Bayar';
                      const lastDate = donor.history[0]?.date || '';
                      
                      return (
                        <div
                          key={donor.id}
                          className="p-3 bg-white border border-slate-100 rounded-3xl flex items-center justify-between gap-3 shadow-[0_2px_6px_rgba(0,0,0,0.01)] animate-fade-in text-left"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            {renderInitialsCircle(donor.name, "h-9 w-9 text-xs")}
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <strong className="text-xs text-slate-800 block truncate font-black">{donor.name}</strong>
                                <span className={`text-[7.5px] font-black px-1.5 py-0.2 rounded uppercase select-none ${badgeBg}`}>
                                  {badgeLabel}
                                </span>
                              </div>
                              <span className="text-[8.5px] text-slate-400 font-semibold block truncate mt-0.5 uppercase tracking-wide">
                                {formatIndonesianDateTime(lastDate)}
                              </span>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-slate-350 block text-[7.5px] uppercase font-bold select-none leading-none mb-0.5">Sumbangan</span>
                            <strong className={`block font-black ${donor.totalContribution === 0 || donor.name === 'Dinna Fajarianti' ? 'text-[9.5px] text-amber-600 font-sans' : 'font-mono text-slate-800 text-[11px]'}`}>
                              {donor.totalContribution === 0 || donor.name === 'Dinna Fajarianti' ? 'Sedang Diverifikasi' : formattedRupiah(donor.totalContribution)}
                            </strong>
                          </div>
                        </div>
                      );
                    });
                  })()}
                </div>
              </div>
            ) : activeCashFlowDetail === 'keluar' ? (
              /* ========================================== */
              /* DETAIL LAPORAN PENGELUARAN                 */
              /* ========================================== */
              <div className="bg-white border border-sage/10 rounded-[32px] p-5 card-shadow space-y-4 animate-fade-in text-left">
                {/* Back Button */}
                <div className="flex justify-between items-center select-none">
                  <button
                    onClick={() => setActiveCashFlowDetail(null)}
                    className="px-3 py-1.5 bg-[#FAF9F5] hover:bg-[#FAF9F5]/70 text-slate-600 border border-slate-200 rounded-xl text-[10px] font-bold cursor-pointer transition-colors flex items-center gap-1 ml-0.5"
                  >
                    <ChevronLeft size={12} />
                    Kembali
                  </button>
                  <span className="text-[8px] bg-amber-500/10 text-amber-808 border border-amber-300/20 font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                     Rincian Dana Keluar
                  </span>
                </div>

                {/* Info and Search bar */}
                <div className="space-y-1 my-0.5 select-none">
                  <span className="text-[8px] text-slate-404 uppercase tracking-widest font-black block">TOTAL DANA KELUAR TERALOKASI</span>
                  <h3 className="serif font-black text-lg text-amber-808 leading-none">
                    {formattedRupiah(totalSpent)}
                  </h3>
                  <p className="text-[10px] text-slate-404 font-semibold mt-1">
                    Berikut adalah seluruh laporan transaksi pengeluaran rill panitia pembangunan masjid.
                  </p>
                </div>

                {/* Sub Search Box */}
                <div className="relative font-bold">
                  <Search size={15} className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-404 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="CARI PENERIMA / KEPERLUAN PENGELUARAN..."
                    value={cashFlowSearchQuery}
                    onChange={(e) => setCashFlowSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-205 focus:border-deep bg-white rounded-2xl text-[9px] font-black uppercase text-slate-705 tracking-wider focus:outline-none transition-all shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)] placeholder:text-slate-404"
                  />
                </div>

                <div className="h-px bg-slate-100" />

                {/* Unified searchable disbursements list */}
                <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                  {(() => {
                    const filteredDisbursements = disbursements.filter(disb => 
                      disb.recipient.toLowerCase().includes(cashFlowSearchQuery.toLowerCase()) ||
                      disb.purpose.toLowerCase().includes(cashFlowSearchQuery.toLowerCase()) ||
                      disb.category.toLowerCase().includes(cashFlowSearchQuery.toLowerCase())
                    );
                    
                    if (filteredDisbursements.length === 0) {
                      return (
                        <div className="text-center py-10 bg-[#FAF9F5] border border-dashed border-slate-150 rounded-3xl text-xs text-slate-404 select-none font-semibold">
                          Data pengeluaran "{cashFlowSearchQuery}" tidak ditemukan
                        </div>
                      );
                    }

                    return filteredDisbursements.slice().reverse().map((disb) => (
                      <div
                        key={disb.id}
                        onClick={() => setSelectedDisbursement(disb)}
                        className="p-3 bg-slate-50 border border-slate-100 hover:bg-slate-100 hover:border-slate-200 rounded-2xl flex gap-3 relative transition-all text-left cursor-pointer active:scale-99"
                        title="Klik untuk detail transaksi kuitansi"
                      >
                        <div className="h-8 w-8 rounded-xl bg-amber-500/10 text-amber-805 border border-slate-100 flex items-center justify-center font-bold text-sm select-none shrink-0">
                          💸
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center select-none">
                            <span className="text-[9px] text-slate-404 font-mono font-medium">{disb.date} • {disb.proofInvoice}</span>
                            <span className="text-[7.5px] bg-sage/20 text-deep font-black px-1.5 py-0.2 rounded uppercase">{disb.category}</span>
                          </div>
                          <h4 className="font-bold text-xs text-slate-800 mt-1">{formattedRupiah(disb.amount)}</h4>
                          <p className="text-[11px] text-slate-650 mt-0.5 leading-relaxed">
                            Penerima: <strong className="text-slate-800">{disb.recipient}</strong>
                            <span className="block italic text-slate-405 mt-0.5">Keperluan: {disb.purpose}</span>
                          </p>
                          <span className="block text-[8px] text-deep font-bold mt-1.5 hover:underline flex items-center gap-0.5">
                            Klik untuk periksa bukti bayar Kuitansi →
                          </span>
                        </div>
                      </div>
                    ));
                  })()}
                </div>
              </div>
            ) : activeCashFlowDetail === 'sisa' ? (
              /* ========================================== */
              /* PERSAMAAN SISA KAS                         */
              /* ========================================== */
              <div className="bg-white border border-sage/10 rounded-[32px] p-5 card-shadow space-y-4 animate-fade-in text-left">
                {/* Back Button */}
                <div className="flex justify-between items-center select-none">
                  <button
                    onClick={() => setActiveCashFlowDetail(null)}
                    className="px-3 py-1.5 bg-[#FAF9F5] hover:bg-[#FAF9F5]/70 text-slate-600 border border-slate-200 rounded-xl text-[10px] font-bold cursor-pointer transition-colors flex items-center gap-1 ml-0.5"
                  >
                    <ChevronLeft size={12} />
                    Kembali
                  </button>
                  <span className="text-[8px] bg-deep/5 text-deep border border-deep/10 font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                     Neraca Sisa Kas
                  </span>
                </div>

                {/* Title */}
                <div className="space-y-1 my-0.5 select-none">
                  <span className="text-[8px] text-slate-404 uppercase tracking-widest font-black block">PERSAMAAN NERACA / SALDO KAS</span>
                  <h3 className="serif font-black text-lg text-deep leading-none">
                    Laporan Persamaan Kas
                  </h3>
                  <p className="text-[10px] text-slate-404 font-semibold mt-1">
                    Berikut adalah kalkulasi sisa dana cadangan pembangunan Masjid yang siap dialokasikan.
                  </p>
                </div>

                <div className="h-px bg-slate-100" />

                {/* Mathematical Equation presentation */}
                <div className="p-5 bg-gradient-to-br from-[#FAF9F5] to-cream/30 border border-sage/15 rounded-3xl space-y-4 relative overflow-hidden select-none">
                  {/* Decorative faint background element */}
                  <div className="absolute right-0 bottom-0 translate-x-4 translate-y-4 opacity-5 scale-125 text-deep">
                    <Receipt size={140} />
                  </div>

                  <span className="text-[8px] font-bold text-[#A3B18A] uppercase tracking-wider block border-b border-dashed border-slate-200/60 pb-1.5">
                    BUKTI HITUNG SALDO REKONSILIASI
                  </span>

                  <div className="space-y-3 font-sans">
                    {/* Item A - Dana Masuk */}
                    <div className="flex justify-between items-center text-xs">
                      <div>
                        <span className="text-slate-500 font-medium block">Total Dana Masuk</span>
                        <span className="text-[8.5px] uppercase tracking-wide text-emerald-600 font-bold">Penerimaan Bruto</span>
                      </div>
                      <span className="font-mono text-emerald-700 font-extrabold text-sm">
                        + {formattedRupiah(totalCollected)}
                      </span>
                    </div>

                    {/* Item B - Dana Keluar */}
                    <div className="flex justify-between items-center text-xs">
                      <div>
                        <span className="text-slate-500 font-medium block">Total Dana Keluar</span>
                        <span className="text-[8.5px] uppercase tracking-wide text-amber-600 font-bold">Rencana & Pengeluaran</span>
                      </div>
                      <span className="font-mono text-amber-808 font-extrabold text-sm">
                        - {formattedRupiah(totalSpent)}
                      </span>
                    </div>

                    {/* Ledger Line */}
                    <div className="flex justify-between items-center border-t border-slate-350 border-dashed pt-2">
                      <span className="text-slate-400 font-semibold block">Operator</span>
                      <span className="text-[9px] text-slate-400 font-mono font-bold uppercase select-none">Pengurangan (-)</span>
                    </div>

                    {/* Left Balance - Sisa Kas */}
                    <div className="flex justify-between items-center pt-1">
                      <div>
                        <span className="text-deep font-serif italic font-black block text-sm">Sisa Kas Saat Ini</span>
                        <span className="text-[8.4px] text-slate-404 font-extrabold tracking-widest uppercase">Saldo Bersih (Netto)</span>
                      </div>
                      <strong className="text-base font-mono text-deep font-black underline decoration-double decoration-deep/30">
                        = {formattedRupiah(totalCollected - totalSpent)}
                      </strong>
                    </div>
                  </div>
                </div>

                {/* Additional Explanation card */}
                <div className="bg-slate-50/75 border border-slate-200/50 p-4 rounded-2xl text-[10.5px] leading-relaxed text-slate-655 font-semibold space-y-2">
                  <div className="flex items-center gap-1.5 text-deep font-bold select-none text-[10px] uppercase tracking-wide">
                    <span>💡 Keterangan & Jaminan Amanah</span>
                  </div>
                  <p>
                    Seluruh sisa saldo tersimpan dalam rekening resmi Bank Syariah Indonesia atas nama kepengurusan pembangunan fisik Masjid An-Nur. 
                  </p>
                  <p>
                    Dana sisa senilai <strong>{formattedRupiah(totalCollected - totalSpent)}</strong> terus dikelola secara terbuka & diaudit oleh Bendahara Pembangunan, Bapak H. Iwan. Jazakumullah khairan katsiran.
                  </p>
                </div>
              </div>
            ) : (
              /* Tampilan Utama */
              <>
                {/* Ringkasan Arus Kas – Stacked Vertically as Elegant Buttons */}
                <div className="bg-white border border-sage/10 p-5 rounded-3xl card-shadow space-y-3.5 text-left select-none">
                  <span className="text-[9px] font-black text-[#A3B18A] uppercase tracking-widest block">
                    Ringkasan Arus Kas Masjid (Detail)
                  </span>
                  
                  <div className="flex flex-col gap-2.5">
                    {/* BUTTON DANA MASUK */}
                    <button
                      type="button"
                      onClick={() => {
                        setActiveCashFlowDetail('masuk');
                        setCashFlowSearchQuery('');
                      }}
                      className="w-full p-3.5 bg-emerald-500/5 hover:bg-emerald-500/10 active:scale-[0.99] border border-emerald-500/10 hover:border-emerald-300/30 rounded-2xl flex items-center justify-between text-left transition-all cursor-pointer shadow-[0_2px_6px_rgba(16,185,129,0.02)]"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-2xl bg-emerald-500/10 text-emerald-700 flex items-center justify-center font-bold text-sm shrink-0">
                          📥
                        </div>
                        <div>
                          <span className="text-[10.5px] uppercase font-black text-slate-800 tracking-wider block">Dana Masuk</span>
                          <span className="text-[8.5px] text-slate-400 font-semibold block mt-1 leading-none">Penerimaan dari jamaah & donatur</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 font-sans">
                        <strong className="text-sm font-mono text-emerald-700 font-extrabold">{formattedRupiah(totalCollected)}</strong>
                        <ChevronRight size={14} className="text-emerald-400 shrink-0" />
                      </div>
                    </button>

                    {/* BUTTON DANA KELUAR */}
                    <button
                      type="button"
                      onClick={() => {
                        setActiveCashFlowDetail('keluar');
                        setCashFlowSearchQuery('');
                      }}
                      className="w-full p-3.5 bg-amber-500/5 hover:bg-amber-500/10 active:scale-[0.99] border border-amber-500/10 hover:border-amber-300/30 rounded-2xl flex items-center justify-between text-left transition-all cursor-pointer shadow-[0_2px_6px_rgba(245,158,11,0.02)]"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-2xl bg-amber-500/10 text-amber-708 flex items-center justify-center font-bold text-sm shrink-0">
                          💸
                        </div>
                        <div>
                          <span className="text-[10.5px] uppercase font-black text-slate-800 tracking-wider block">Dana Keluar</span>
                          <span className="text-[8.5px] text-slate-400 font-semibold block mt-1 leading-none">Alokasi & realisasi pembelanjaan RAB</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 font-sans">
                        <strong className="text-sm font-mono text-amber-808 font-extrabold">{formattedRupiah(totalSpent)}</strong>
                        <ChevronRight size={14} className="text-amber-400 shrink-0" />
                      </div>
                    </button>

                    {/* BUTTON SISA KAS */}
                    <button
                      type="button"
                      onClick={() => {
                        setActiveCashFlowDetail('sisa');
                        setCashFlowSearchQuery('');
                      }}
                      className="w-full p-3.5 bg-slate-50 hover:bg-slate-100 active:scale-[0.99] border border-slate-205/60 hover:border-slate-300 rounded-2xl flex items-center justify-between text-left transition-all cursor-pointer shadow-[0_2px_6px_rgba(0,0,0,0.01)]"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-2xl bg-deep/5 text-deep flex items-center justify-center font-bold text-sm select-none shrink-0 border border-deep/10">
                          💼
                        </div>
                        <div>
                          <span className="text-[10.5px] uppercase font-black text-deep tracking-wider block">Sisa Kas</span>
                          <span className="text-[8.5px] text-slate-404 font-semibold block mt-1 leading-none">Dana bersih kas tersimpan</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 font-sans">
                        <strong className="text-sm font-mono text-deep font-black underline decoration-double decoration-sage/35">{formattedRupiah(totalCollected - totalSpent)}</strong>
                        <ChevronRight size={14} className="text-slate-404 shrink-0" />
                      </div>
                    </button>
                  </div>
                </div>

                {/* Rincian Alokasi RAB (Budgets) */}
                <div className="bg-white border border-sage/10 rounded-3xl p-4 card-shadow space-y-3 text-left">
              <div className="flex justify-between items-baseline select-none">
                <h3 className="font-bold text-[11px] text-slate-800 uppercase tracking-wide">RINCIAN PENGELUARAN BERDASARKAN POS ALOKASI RAB</h3>
                <span className="text-[10px] text-deep font-semibold">Tabel Akuntabel</span>
              </div>

              <div className="space-y-3">
                {allocations.map((alloc) => {
                  const spentPercent = alloc.estimatedCost > 0 
                    ? Math.min((alloc.actualSpent / alloc.estimatedCost) * 100, 100) 
                    : 0;
                  
                  return (
                    <div 
                      key={alloc.id} 
                      onClick={() => setSelectedAllocation(alloc)}
                      className="border-b border-slate-100 last:border-none pb-2.5 last:pb-0 space-y-1.5 cursor-pointer hover:bg-[#FAF9F5] p-2 -mx-2 rounded-2xl transition-colors text-left font-sans animate-fade-in"
                      title="Klik untuk detail breakdown"
                    >
                      <div className="flex justify-between items-baseline text-xs">
                        <strong className="font-bold text-slate-800 leading-snug hover:text-deep flex items-center gap-1">
                          {alloc.item}
                          <ChevronRight size={12} className="text-slate-400 inline shrink-0" />
                        </strong>
                        <span className="text-[9px] bg-slate-100 px-1.5 py-0.2 rounded text-slate-500 font-mono scale-95 shrink-0 select-none">
                          {alloc.category}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-2 text-[10.5px] text-slate-500 select-none">
                        <div>
                          <span>Est. RAB: </span>
                          <strong className="text-slate-800 font-mono">{formattedRupiah(alloc.estimatedCost)}</strong>
                        </div>
                        <div className="text-right">
                          <span>Realisasi Belanja: </span>
                          <strong className="text-deep font-bold font-mono">{formattedRupiah(alloc.actualSpent)}</strong>
                        </div>
                      </div>

                      {/* Micro visual progression */}
                      <div className="space-y-1">
                        <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-deep transition-all rounded-full" 
                            style={{ width: `${spentPercent}%` }}
                          />
                        </div>
                        <div className="flex justify-between items-center text-[8.5px] text-slate-400 select-none">
                          <span>Status Pos: <strong className="text-slate-500">{alloc.status}</strong></span>
                          <span>Teralokasi: {spentPercent.toFixed(0)}%</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Penyaluran Dana Riwayat (Disbursements History) */}
            <div className="bg-white border border-sage/10 rounded-3xl p-4 card-shadow space-y-3 text-left">
              <div className="flex justify-between items-baseline select-none">
                <h3 className="font-bold text-[11px] text-slate-800 uppercase tracking-wide">UPDATE PENGELUARAN PANITIA PEMBANGUNAN</h3>
                {/* Terbukti nyata dihilangkan sesuai request */}
              </div>

              <div className="space-y-3">
                {disbursements.slice().reverse().map((disb) => (
                  <div
                    key={disb.id}
                    onClick={() => setSelectedDisbursement(disb)}
                    className="p-3 bg-slate-50 border border-slate-100 hover:bg-slate-100 hover:border-slate-200 rounded-2xl flex gap-3 relative transition-all text-left cursor-pointer active:scale-99"
                    title="Klik untuk detail transaksi kuitansi"
                  >
                    <div className="h-8 w-8 rounded-xl bg-amber-500/10 text-amber-805 border border-slate-100 flex items-center justify-center font-bold text-sm select-none shrink-0">
                      💸
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center select-none">
                        <span className="text-[9px] text-slate-404 font-mono font-medium">{disb.date} • {disb.proofInvoice}</span>
                        <span className="text-[8px] bg-sage/20 text-deep font-extrabold px-1.5 py-0.2 rounded uppercase">DIBAYARKAN</span>
                      </div>
                      <h4 className="font-bold text-xs text-slate-800 mt-1">{formattedRupiah(disb.amount)}</h4>
                      <p className="text-[11px] text-slate-650 mt-0.5 leading-relaxed">
                        Penerima: <strong className="text-slate-800">{disb.recipient}</strong>
                        <span className="block italic text-slate-405 mt-0.5">Keperluan: {disb.purpose}</span>
                      </p>
                      <span className="block text-[8px] text-deep font-bold mt-1.5 hover:underline flex items-center gap-0.5">
                        Klik untuk periksa bukti bayar Kuitansi →
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
          </div>
        )}

        {/* ======================================= */}
        {/* SECTION B: DAFTAR PENYUMBANG AKTIF      */}
        {/* ======================================= */}
        {currentSection === 'donatur-list' && !selectedDonorProfile && (() => {
          const mCount = donors.filter(d => d.type === 'monthly').length;
          const mSum = donors.filter(d => d.type === 'monthly').reduce((acc, d) => acc + d.totalContribution, 0);

          const oCount = donors.filter(d => d.type === 'one-time').length;
          const oSum = donors.filter(d => d.type === 'one-time').reduce((acc, d) => acc + d.totalContribution, 0);

          const totalNum = mCount + oCount;
          const totalAll = mSum + oSum;

          return (
            <div className="space-y-4 animate-fade-in">
              {/* Ringkasan Penyumbang Card */}
              <div className="bg-white border border-sage/10 rounded-3xl p-5 card-shadow space-y-4 text-left">
                <span className="text-[9px] text-[#A3B18A] block font-black tracking-widest uppercase">
                  RINGKASAN PENYUMBANG PEMBANGUNAN MASJID
                </span>

                <div className="space-y-3.5 pt-1">
                  {/* Row Iuran Bulanan */}
                  <div className="flex items-center justify-between border-b border-slate-100/70 pb-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-2xl bg-teal-500/10 text-teal-750 flex flex-col items-center justify-center select-none shrink-0 scale-95 border border-teal-300/10 shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)]">
                        <Users size={15} className="text-teal-600" />
                        <div className="flex items-baseline gap-0.5 mt-0.5 leading-none">
                          <span className="text-[9px] font-mono font-bold">{mCount}</span>
                          <span className="text-[6.5px] text-slate-400 font-bold scale-90">Org</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10.5px] uppercase font-bold text-slate-800 tracking-wider">Iuran Bulanan</span>
                        <span className="text-[8.5px] text-slate-400 block font-medium">Komitmen Jangka Panjang</span>
                      </div>
                    </div>
                    <strong className="text-xs font-mono text-slate-700 font-extrabold">{formattedRupiah(mSum)}</strong>
                  </div>

                  {/* Row Sekali Bayar */}
                  <div className="flex items-center justify-between border-b border-slate-100/70 pb-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-2xl bg-amber-500/10 text-amber-808 flex flex-col items-center justify-center select-none shrink-0 scale-95 border border-amber-300/10 shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)]">
                        <User size={15} className="text-amber-500" />
                        <div className="flex items-baseline gap-0.5 mt-0.5 leading-none">
                          <span className="text-[9px] font-mono font-bold">{oCount}</span>
                          <span className="text-[6.5px] text-slate-400 font-bold scale-90">Org</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10.5px] uppercase font-bold text-slate-800 tracking-wider">Donasi Sekali Bayar</span>
                        <span className="text-[8.5px] text-slate-400 block font-medium">Untuk Kebutuhan Mendesak</span>
                      </div>
                    </div>
                    <strong className="text-xs font-mono text-slate-700 font-extrabold">{formattedRupiah(oSum)}</strong>
                  </div>

                  {/* Row Total */}
                  <div className="flex items-center justify-between pt-0.5">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-2xl bg-deep/5 text-deep flex flex-col items-center justify-center select-none shrink-0 scale-95 border border-deep/10 shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)]">
                        <CreditCard size={15} className="text-deep/80" />
                        <div className="flex items-baseline gap-0.5 mt-0.5 leading-none">
                          <span className="text-[9px] font-mono font-bold">{totalNum}</span>
                          <span className="text-[6.5px] text-slate-400 font-bold scale-90">Org</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[11px] uppercase font-black text-deep tracking-wider">Total Pembukuan</span>
                        <span className="text-[8.5px] text-slate-400 block font-semibold">Akumulasi Seluruh Sumbangan</span>
                      </div>
                    </div>
                    <strong className="text-xs font-mono text-deep font-black underline decoration-double decoration-sage/30">{formattedRupiah(totalAll)}</strong>
                  </div>
                </div>
              </div>

              {/* Search Box */}
              <div className="relative">
                <Search size={15} className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  placeholder="CARI NAMA PENYUMBANG MASJID DISINI"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-slate-205 focus:border-deep bg-white rounded-2xl text-[9.5px] font-black uppercase text-slate-705 tracking-wider focus:outline-none transition-all shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)] placeholder:text-slate-400 placeholder:font-bold"
                />
              </div>

              {/* Sub-tabs Selector */}
              <div className="grid grid-cols-2 bg-slate-100/70 p-1 rounded-[22px] border border-slate-200/40 text-center gap-1 select-none">
                <button
                  type="button"
                  onClick={() => setDonorSubTab('one-time')}
                  className={`flex flex-col items-center justify-center py-2 px-2 rounded-2xl transition-all cursor-pointer ${
                    donorSubTab === 'one-time'
                      ? 'bg-white text-deep shadow-[0_4px_12px_rgba(0,0,0,0.04)] font-bold scale-[1.01] border border-slate-200/20'
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-black uppercase tracking-wider">Donasi Sekali Bayar</span>
                  <span className={`text-[7.5px] mt-0.5 font-bold leading-none ${donorSubTab === 'one-time' ? 'text-amber-600' : 'text-slate-400'}`}>Untuk Kebutuhan Mendesak</span>
                </button>
                
                <button
                  type="button"
                  onClick={() => setDonorSubTab('monthly')}
                  className={`flex flex-col items-center justify-center py-2 px-2 rounded-2xl transition-all cursor-pointer ${
                    donorSubTab === 'monthly'
                      ? 'bg-white text-deep shadow-[0_4px_12px_rgba(0,0,0,0.04)] font-bold scale-[1.01] border border-slate-200/20'
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-black uppercase tracking-wider">Iuran Bulanan (Years)</span>
                  <span className={`text-[7.5px] mt-0.5 font-bold leading-none ${donorSubTab === 'monthly' ? 'text-teal-600' : 'text-slate-400'}`}>Komitmen Jangka Panjang</span>
                </button>
              </div>

              {/* Dynamic list rendering based on donorSubTab */}
              <div className="space-y-2.5">
                {donorSubTab === 'one-time' ? (
                  /* SEKALI BAYAR LIST */
                  oneTimeDonorsList.length === 0 ? (
                    <div className="text-center py-10 bg-white border border-dashed border-slate-150 rounded-3xl text-xs text-slate-400">
                      Tidak ada hasil ditemukan untuk "{searchQuery}"
                    </div>
                  ) : (
                    oneTimeDonorsList.map((donor) => (
                      <div
                        key={donor.id}
                        className="p-3 bg-white border border-slate-100 hover:border-sage/20 rounded-3xl flex items-center justify-between gap-3 shadow-[0_2px_8px_rgba(0,0,0,0.01)] transition-colors animate-fade-in text-left"
                      >
                        <div className="flex items-center gap-3 min-w-0 select-none">
                          {renderInitialsCircle(donor.name, "h-9 w-9 text-xs")}
                          <div className="min-w-0 text-left">
                            <strong className="text-xs text-slate-800 block truncate font-black">{donor.name}</strong>
                            <span className="text-[8.5px] text-slate-400 font-semibold block truncate mt-0.5 uppercase tracking-wide">
                              {formatIndonesianDateTime(donor.history[0]?.date)}
                            </span>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-slate-350 block text-[7.5px] uppercase font-bold select-none leading-none mb-0.5">Sumbangan</span>
                          <strong className={`block font-black ${donor.totalContribution === 0 ? 'text-[9.5px] text-amber-600 font-sans' : 'font-mono text-slate-800 text-[11px]'}`}>
                            {donor.totalContribution === 0 ? 'Sedang Diverifikasi' : formattedRupiah(donor.totalContribution)}
                          </strong>
                        </div>
                      </div>
                    ))
                  )
                ) : (
                  /* MONTHLY COMMIT LIST */
                  activeMonthlyDonors.length === 0 ? (
                    <div className="text-center py-10 bg-white border border-dashed border-slate-150 rounded-3xl text-xs text-slate-400">
                      Tidak ada hasil ditemukan untuk "{searchQuery}"
                    </div>
                  ) : (
                    activeMonthlyDonors.map((donor) => (
                      <div
                        key={donor.id}
                        onClick={() => setSelectedDonorProfile(donor)}
                        id={`active-donor-row-${donor.id}`}
                        className="p-3 bg-white hover:bg-sage/5 hover:border-sage/20 border border-slate-100 rounded-3xl flex items-center justify-between gap-3 cursor-pointer shadow-[0_2px_8px_rgba(0,0,0,0.01)] transition-colors animate-fade-in text-left"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {renderInitialsCircle(donor.name, "h-9 w-9 text-xs")}
                          <div className="min-w-0 text-left">
                            <strong className="text-xs text-slate-800 block truncate font-black">{donor.name}</strong>
                            <span className="text-[8.5px] text-slate-400 font-bold block mt-0.5">
                              Commit: {formattedRupiah(donor.monthlyCommitment!)} / bln • {donor.periodYears} Thn
                            </span>
                          </div>
                        </div>
                        <div className="text-right shrink-0 flex items-center gap-1.5">
                          <div className="text-[10px]">
                            <span className="text-slate-350 block text-[7.5px] uppercase font-bold leading-none mb-0.5">Total Donasi</span>
                            <strong className={`font-semibold block ${donor.totalContribution === 0 || donor.name === 'Dinna Fajarianti' ? 'text-[9.5px] text-amber-600 font-sans font-bold' : 'font-mono text-deep font-black text-[11px]'}`}>
                              {donor.totalContribution === 0 || donor.name === 'Dinna Fajarianti' ? 'Sedang Diverifikasi' : formattedRupiah(donor.totalContribution)}
                            </strong>
                          </div>
                          <ChevronRight size={13} className="text-slate-300" />
                        </div>
                      </div>
                    ))
                  )
                )}
              </div>
            </div>
          );
        })()}

        {/* ======================================= */}
        {/* PROFILE VIEWER SECTION (Halaman Profil) */}
        {/* ======================================= */}
        {currentSection === 'donatur-list' && selectedDonorProfile && (
          <div className="bg-white border border-sage/10 rounded-[32px] p-5 card-shadow space-y-5 animate-fade-in relative select-none">
            
            {/* Back button */}
            <button
              onClick={() => setSelectedDonorProfile(null)}
              className="absolute top-4 right-4 px-3 py-1 bg-[#FAF9F5] hover:bg-slate-100 text-slate-650 border border-slate-200 rounded-xl text-[10px] font-bold cursor-pointer transition-colors"
            >
              Kembali
            </button>

            {/* Profile Avatar & Name banner */}
            <div className="flex flex-col items-center justify-center text-center space-y-2 pt-2">
              {renderInitialsCircle(selectedDonorProfile.name, "h-16 w-16 text-lg")}
              <div>
                <h3 className="serif font-extrabold text-sm text-deep leading-tight">{selectedDonorProfile.name}</h3>
                <div className="text-[10px] text-slate-400 font-mono space-y-0.5 mt-0.5 select-all">
                  <div>{selectedDonorProfile.email}</div>
                  {selectedDonorProfile.phone && (
                    <div>HP: {selectedDonorProfile.phone.slice(0, -3)}***</div>
                  )}
                </div>
                <div className="flex justify-center items-center gap-1.5 mt-2">
                  <span className="bg-sage/15 text-deep border border-sage/25 text-[8.5px] font-bold px-2 py-0.5 rounded-full uppercase tracking-widest">
                    Penyumbang Bulanan Aktif
                  </span>
                </div>
              </div>
            </div>

            <div className="h-px bg-slate-100" />

            {/* Metrics cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#FAF9F5] p-3 rounded-2xl border border-sage/10 text-center">
                <span className="text-[8px] text-slate-400 uppercase tracking-wider block font-bold">AKUMULASI KONTRIBUSI</span>
                <strong className={`font-extrabold block mt-1 ${selectedDonorProfile.totalContribution === 0 || selectedDonorProfile.name === 'Dinna Fajarianti' ? 'text-xs text-amber-600 font-sans font-bold' : 'text-sm font-mono text-deep'}`}>
                  {selectedDonorProfile.totalContribution === 0 || selectedDonorProfile.name === 'Dinna Fajarianti' ? 'Sedang Diverifikasi' : formattedRupiah(selectedDonorProfile.totalContribution)}
                </strong>
              </div>
              <div className="bg-[#FAF9F5] p-3 rounded-2xl border border-sage/10 text-center">
                <span className="text-[8px] text-slate-400 uppercase tracking-wider block font-bold">KOMITMEN BULANAN</span>
                <strong className="text-sm font-mono text-slate-800 font-bold block mt-1">
                  {formattedRupiah(selectedDonorProfile.monthlyCommitment || 0)} / Thn
                </strong>
              </div>
            </div>

            {/* History Payments checklist */}
            <div className="space-y-2.5 text-slate-705">
              <h4 className="serif font-bold text-[10.5px] text-deep uppercase tracking-wider text-left">RIWAYAT ALIRAN SETORAN DONASI</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                {selectedDonorProfile.history.map((h) => (
                  <div key={h.id} className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between text-[11px]">
                    <div className="min-w-0 text-left">
                      <span className="text-[8px] text-slate-400 font-mono block">{h.date} • {h.invoiceNumber}</span>
                      <strong className="text-slate-700 block truncate font-semibold">{h.description}</strong>
                    </div>
                    <strong className="font-mono text-deep shrink-0 font-bold">{formattedRupiah(h.amount)}</strong>
                  </div>
                ))}
              </div>
            </div>

            {/* Sertifikat Piagam Penghargaan Digital */}
            <div className="border border-amber-500/30 bg-amber-500/5 rounded-3xl p-4 text-center space-y-3 relative overflow-hidden select-none border-dashed">
              <div className="absolute -top-10 -right-10 h-28 w-28 bg-amber-500/10 rounded-full filter blur-xl pointer-events-none" />
              <div className="absolute -bottom-10 -left-10 h-28 w-28 bg-deep/5 rounded-full filter blur-xl pointer-events-none" />

              <div className="text-[#D6AB1E] mx-auto justify-center flex filter drop-shadow-[0_2px_8px_rgba(214,171,30,0.45)]">
                <Award size={40} className="stroke-[2.5]" />
              </div>
              <div className="space-y-1">
                <span className="font-serif italic text-amber-900 text-xs tracking-wider block font-semibold">Piagam Penghargaan Mulia</span>
                <h4 className="serif font-bold text-[10px] uppercase text-deep tracking-widest leading-none">MASJID AN-NUR BUMI DAYA INDAH</h4>
                <p className="text-[9.5px] text-slate-650 leading-relaxed max-w-xs mx-auto pt-1">
                  Diberikan dengan rasa hormat terdalam kepada Bapak/Ibu <strong>{selectedDonorProfile.name}</strong> atas keistiqomahan menyalurkan sumbangan pembangunan fisik rumah ibadah kami. Semoga menjadi zakat jariyah yang kekal dunia akhirat.
                </p>
              </div>

              <div className="pt-2 border-t border-slate-200/50 flex justify-between items-center text-[8px] text-slate-455 font-mono">
                <span>ID Piagam: CERT/AN-NUR/{selectedDonorProfile.id.toUpperCase()}</span>
                <span className="font-bold text-deep">SAH Terverifikasi Audit</span>
              </div>
            </div>
          </div>
        )}

        {/* ======================================= */}
        {/* SECTION C: DASHBOARD KHUSUS DONATUR     */}
        {/* ======================================= */}
        {currentSection === 'dashboard-khusus' && (
          <div className="space-y-4 animate-fade-in text-xs text-slate-705">
            {/* Account Selector simulation */}
            <div className="bg-white border border-sage/10 rounded-3xl p-4 card-shadow space-y-3 select-none">
              <label className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1 text-left">
                🛡️ Masuk sebagai Profil Donatur untuk Cek Dashboard Khusus
              </label>
              <div className="flex gap-2">
                <select
                  value={personalDashboardDonorId || ''}
                  onChange={(e) => setPersonalDashboardDonorId(e.target.value)}
                  className="flex-1 px-3 py-2 border rounded-xl bg-slate-55 text-xs focus:outline-none focus:border-deep text-slate-705"
                >
                  <option value="" disabled>-- Pilih Akun Donatur --</option>
                  {donors.filter(d => d.type === 'monthly').map((d) => (
                    <option key={d.id} value={d.id}>{d.name} ({d.email})</option>
                  ))}
                </select>
                <div className="px-3 bg-sage/20 text-deep border border-sage/25 rounded-xl flex items-center justify-center font-bold">
                  Demo
                </div>
              </div>
              <p className="text-[10px] text-slate-455 leading-tight text-left">
                Simulasi ini mempermudah donatur melacak alur kontribusi khusus mereka dalam pembukuan real-time.
              </p>
            </div>

            {/* Main personal dashboard profile details */}
            {personalDashboardDonorId && donors.find(d => d.id === personalDashboardDonorId) ? (() => {
              const myDonor = donors.find(d => d.id === personalDashboardDonorId)!;
              const nextMonthNum = (myDonor.monthsPaid || 0) + 1;
              const isLunas = nextMonthNum > (myDonor.totalMonthsCommit || 24);

              return (
                <div className="space-y-4">
                  {/* Personal Welcome Card */}
                  <div className="bg-gradient-to-br from-[#2D3E35] to-deep text-white rounded-3xl p-4 shadow-md space-y-3 relative overflow-hidden select-none">
                    <div className="absolute right-0 top-0 translate-x-3 -translate-y-3 opacity-10 scale-110 text-cream p-1">
                      <ShieldCheck size={120} />
                    </div>

                    <div className="flex justify-between items-baseline">
                      <span className="text-[8.5px] uppercase font-bold tracking-widest text-[#E3A008] bg-white/10 px-2 py-0.5 rounded-full border border-white/5">
                        DASHBOARD KHUSUS DONATUR
                      </span>
                      <span className="text-[9px] font-mono text-slate-300">ID: {myDonor.email.split('@')[0].toUpperCase()}</span>
                    </div>

                    <div className="flex gap-3 items-center">
                      {renderInitialsCircle(myDonor.name, "h-11 w-11 text-xs", "dark")}
                      <div className="text-left">
                        <h3 className="serif font-extrabold text-sm tracking-wide leading-tight">{myDonor.name}</h3>
                        <span className="text-[10px] text-slate-300 block mt-0.5">{myDonor.email}</span>
                      </div>
                    </div>

                    <div className="h-px bg-white/10 my-1" />

                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div className="bg-white/5 p-2 rounded-xl border border-white/5 text-center">
                        <span className="text-[8px] text-slate-300 block font-bold leading-none">KONTRIBUSI SAYA</span>
                        <strong className={`font-mono text-amber-300 font-extrabold block mt-1 ${myDonor.totalContribution === 0 || myDonor.name === 'Dinna Fajarianti' ? 'text-[9px]' : 'text-xs'}`}>
                          {myDonor.totalContribution === 0 || myDonor.name === 'Dinna Fajarianti' ? 'Sedang Diverifikasi' : formattedRupiah(myDonor.totalContribution)}
                        </strong>
                      </div>
                      <div className="bg-white/5 p-2 rounded-xl border border-white/5 text-center">
                        <span className="text-[8px] text-slate-300 block font-bold leading-none">STATUS PLAN</span>
                        <strong className="text-xs font-mono text-cream block mt-1">
                          Bln ke-{myDonor.monthsPaid} / {myDonor.totalMonthsCommit} Bln
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* REAL-TIME FUND DISBURSEMENT TRACKER (Lacak Penyaluran Dana Anda) */}
                  <div className="bg-white border border-sage/10 rounded-3xl p-4 card-shadow space-y-3">
                    <div className="flex justify-between items-baseline select-none">
                      <h4 className="serif font-bold text-[10.5px] text-deep uppercase tracking-wider text-left">Lacak Penyaluran Donasi Saya</h4>
                      <span className="text-[10px] text-deep font-bold bg-sage/20 px-2.5 py-0.5 rounded">Real-Time Alokasi</span>
                    </div>

                    {/* Simulation showing where their money went */}
                    <div className="space-y-3">
                      <div className="p-3 bg-sage/10 border border-sage/15 rounded-2xl space-y-1.5 text-left">
                        <div className="flex justify-between items-baseline select-none">
                          <strong className="text-deep font-extrabold text-[11px]">80% Dana Berhasil Disalurkan</strong>
                          <span className="text-[9px] font-mono font-bold text-deep">Laporan Akuntabel</span>
                        </div>
                        <p className="text-[11.5px] text-slate-655 leading-relaxed">
                          Alhamdulillah, dari akumulasi dana Bapak/Ibu <strong>{myDonor.name}</strong> senilai <strong>{myDonor.totalContribution === 0 || myDonor.name === 'Dinna Fajarianti' ? 'Sedang Diverifikasi' : formattedRupiah(myDonor.totalContribution)}</strong>, {myDonor.totalContribution === 0 || myDonor.name === 'Dinna Fajarianti' ? 'dana Anda sedang diproses oleh tim kami' : `sebesar ${formattedRupiah(myDonor.totalContribution * 0.8)} telah ditarik dan disalurkan langsung secara transparan`} untuk mendanai:
                        </p>
                        
                        <div className="space-y-1 pl-1 text-[10px] font-semibold text-slate-700 font-sans">
                          <div className="flex items-center gap-1">
                            <CornerDownRight size={10} className="text-deep shrink-0 font-bold" />
                            <span>Struktur Beton Utama Masjid (PT Sinar Beton)</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <CornerDownRight size={10} className="text-deep shrink-0 font-bold" />
                            <span>Rangka Rantai & Kerangka Besi Baja Kubah Specialist</span>
                          </div>
                        </div>

                        <div className="h-1 bg-slate-205 rounded-full mt-1.5 overflow-hidden">
                          <div className="h-full bg-deep rounded-full" style={{ width: '80%' }} />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Active commitment paying option (simulate next billing pay) */}
                  <div className="bg-white border border-sage/10 rounded-3xl p-4 card-shadow space-y-3 select-none">
                    <div className="flex justify-between items-baseline">
                      <h4 className="serif font-bold text-[10.5px] text-deep uppercase tracking-wider text-left">Komitmen Bulan Berikutnya</h4>
                      <span className="text-[9px] text-[#E3A008] font-bold">Kewajiban Jariyah</span>
                    </div>

                    {isLunas ? (
                      <div className="bg-sage/15 p-3 rounded-2xl text-center text-deep font-bold border border-sage/25">
                        🎉 Pembayaran Komitmen {myDonor.periodYears} Tahun Anda Telah LUNAS Sepenuhnya!
                        <span className="block text-[10px] font-medium mt-1 text-center">Semoga amal shalih Anda dilipatgandakan pahalanya.</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between p-3 bg-[#FAF9F5] border border-sage/10 rounded-2xl gap-3 text-left">
                        <div>
                          <span className="text-[9px] text-slate-400 block uppercase font-bold">Invoice Terbuka</span>
                          <strong className="text-xs text-slate-800 font-bold mt-0.5 block">Iuran Ke-{nextMonthNum}</strong>
                          <span className="text-[10px] text-deep font-bold font-mono block mt-0.5">
                            {formattedRupiah(myDonor.monthlyCommitment || 0)}
                          </span>
                        </div>
                        <button
                          onClick={() => handlePayNextMonthInvoice(myDonor)}
                          id="pay-next-month-btn"
                          className="px-4 py-2 bg-olive hover:bg-deep text-white text-[10px] font-bold rounded-xl shadow cursor-pointer active:scale-95 transition-all text-center"
                        >
                          Bayar Iuran (Simulasi)
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Receipts history check */}
                  <div className="bg-white border border-sage/10 rounded-3xl p-4 card-shadow space-y-2">
                    <h4 className="serif font-bold text-[10.5px] text-deep uppercase tracking-wider select-none text-left font-bold">Riwayat Transaksi Pribadi Saya</h4>
                    <div className="space-y-1.5 select-none text-left">
                      {myDonor.history.map((h) => (
                        <div key={h.id} className="p-2.5 bg-[#FAF9F5] border border-sage/10 rounded-xl flex items-center justify-between">
                          <div>
                            <span className="text-[8px] text-slate-400 font-mono block">{h.date}</span>
                            <span className="font-bold text-[11px] text-slate-850">{h.description}</span>
                          </div>
                          <div className="text-right flex flex-col items-end">
                            <span className="font-mono text-deep font-bold block">{formattedRupiah(h.amount)}</span>
                            <span className="text-[8px] bg-sage/20 text-deep border border-sage/30 font-bold px-1 rounded uppercase">SUKSES</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })() : (
              <div className="text-center py-10 bg-white border border-slate-100 rounded-3xl select-none text-slate-400 text-xs">
                Silakan pilih akun donatur di atas untuk melihat dashboard personal mereka.
              </div>
            )}
          </div>
        )}
      </div>

      {/* ======================================================= */}
      {/* DETAILED RECEIPT MODAL FOR CLICKED DISBURSEMENTS      */}
      {/* ======================================================= */}
      {selectedDisbursement && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl overflow-hidden card-shadow border border-sage/15 text-slate-800 relative">
            
            {/* Header branding */}
            <div className="bg-deep text-cream px-5 py-4 flex justify-between items-center select-none">
              <div className="flex items-center gap-1.5">
                <Receipt size={16} className="text-cream" />
                <span className="serif text-xs font-extrabold tracking-wider uppercase">Bukti Pengeluaran Kas</span>
              </div>
              <button 
                onClick={() => setSelectedDisbursement(null)}
                className="h-6 w-6 rounded-full hover:bg-white/10 flex items-center justify-center text-cream cursor-pointer transition-colors"
                aria-label="Tutup"
              >
                <X size={15} />
              </button>
            </div>

            {/* Receipt body simulating classical paper voucher */}
            <div className="p-6 space-y-4 text-xs">
              
              {/* Paper Top section */}
              <div className="text-center pb-2 border-b border-dashed border-slate-200">
                <h4 className="serif font-black text-slate-900 tracking-wide text-[11px]">PANITIA REKONSTRUKSI MASJID AN-NUR</h4>
                <p className="text-[9px] text-slate-400 font-mono mt-0.5">Jl. Bumi Daya Indah, Kel. Paccerakkang, Makassar</p>
              </div>

              {/* Invoice details */}
              <div className="space-y-2 font-sans">
                <div className="flex justify-between">
                  <span className="text-slate-400">Nomor Kuitansi</span>
                  <strong className="font-mono text-slate-900">{selectedDisbursement.proofInvoice || 'INV/OUT/2026/05/'}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Tanggal Pengeluaran</span>
                  <span className="font-medium text-slate-800">{selectedDisbursement.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Sektor Anggaran</span>
                  <span className="px-1.5 py-0.2 bg-slate-100 rounded text-[9.5px] font-bold text-slate-600 font-mono">{selectedDisbursement.category}</span>
                </div>
              </div>

              <div className="h-px bg-slate-100" />

              {/* Amount showcase */}
              <div className="bg-[#FAF9F5] p-3 rounded-2xl border border-sage/10 text-center space-y-1">
                <span className="text-[9px] uppercase font-bold tracking-widest text-[#A3B18A] block">JUMLAH YANG DIBAYARKAN</span>
                <strong className="text-sm font-mono text-deep font-black block">{formattedRupiah(selectedDisbursement.amount)}</strong>
              </div>

              {/* Transaction elements */}
              <div className="space-y-2.5 md:space-y-3">
                <div>
                  <span className="text-slate-404 block text-[9px] uppercase font-bold tracking-wide">Penerima Dana (Mitra / Toko)</span>
                  <strong className="text-slate-900 text-[11px] block mt-0.5">{selectedDisbursement.recipient}</strong>
                </div>
                <div>
                  <span className="text-slate-404 block text-[9px] uppercase font-bold tracking-wide">Tujuan Rincian Keperluan</span>
                  <p className="text-slate-600 text-[11.5px] leading-relaxed mt-0.5">{selectedDisbursement.purpose}</p>
                </div>
              </div>

              {/* Stamp and signature segment */}
              <div className="pt-4 border-t border-dashed border-slate-200 flex justify-between items-center select-none">
                <div className="border border-green-600/30 text-green-700 bg-green-500/5 px-2.5 py-1 rounded-lg text-[9px] font-extrabold uppercase tracking-widest -rotate-4 scale-95 border-double">
                  Lunas Dibayar
                </div>
                <div className="text-right text-[9.5px]">
                  <span className="text-slate-400 block">Bendahara Pembangunan,</span>
                  <span className="font-serif italic font-bold text-slate-800 block mt-4 mr-2">H. Iwan</span>
                </div>
              </div>
            </div>

            {/* Print friendly note */}
            <div className="bg-slate-50 px-5 py-3 border-t border-slate-100 text-center select-none text-[9.5px] text-slate-400">
              Kuitansi sah diverifikasi secara digital oleh audit publik sistem transparansi.
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
