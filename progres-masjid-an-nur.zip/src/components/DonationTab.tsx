/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Gift, Calendar, ArrowRight, Heart, Sparkles, CheckCircle2, ChevronRight, Hash, Send, Landmark, QrCode } from 'lucide-react';
import { Donor, DonationRecord, Proposal } from '../types';

interface DonationTabProps {
  totalTarget: number;
  totalCollected: number;
  proposals: Proposal[];
  onAddDonation: (donorData: Omit<Donor, 'id' | 'history'>, amount: number, record: Omit<DonationRecord, 'id' | 'invoiceNumber' | 'status'>) => void;
}

export const DonationTab: React.FC<DonationTabProps> = ({
  totalTarget,
  totalCollected,
  proposals,
  onAddDonation
}) => {
  const [modelOption, setModelOption] = useState<'monthly' | 'one-time'>('one-time');
  
  // Payment Simulation State
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [invoiceData, setInvoiceData] = useState<{
    name: string;
    phone: string;
    type: 'monthly' | 'one-time';
    amount: number;
    monthlyCommitment?: number;
    periodYears?: number;
    proposalTarget?: string;
    bankName: string;
    virtualAccount: string;
    invoiceNumber: string;
  } | null>(null);

  const [paymentStep, setPaymentStep] = useState<'billing' | 'paying' | 'success'>('billing');

  // Form States
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState(500000); // For single pay
  const [monthlyCommitment, setMonthlyCommitment] = useState(500000); // Monthly commit slider
  const [periodYears, setPeriodYears] = useState(2); // In years
  const [proposalTarget, setProposalTarget] = useState('p2'); // Selected proposal target
  const [selectedBank, setSelectedBank] = useState('MANDIRI');

  const progressPercent = Math.min((totalCollected / totalTarget) * 100, 100);
  const remainingNeeded = Math.max(totalTarget - totalCollected, 0);

  // Suggested quick amounts
  const QUICK_SINGLE_AMOUNTS = [100000, 250000, 500000, 1000000, 2500000, 5000000];
  const QUICK_MONTHLY_AMOUNTS = [100000, 250000, 500000, 1000000, 2000000, 3000000];

  const handleCreateDonationInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    let finalAmount = amount;
    if (modelOption === 'monthly') {
      // Monthly amount * 12 months * years
      finalAmount = monthlyCommitment; // We record first monthly chunk payment directly, but calculate full plan.
    }

    const randomVA = Math.floor(1000000000000000 + Math.random() * 9000000000000000).toString();
    const invoiceNum = `INV/AN-NUR/${Date.now().toString().slice(-6)}`;

    const titleCasedName = name
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

    setInvoiceData({
      name: titleCasedName,
      phone,
      type: modelOption,
      amount: finalAmount,
      monthlyCommitment: modelOption === 'monthly' ? monthlyCommitment : undefined,
      periodYears: modelOption === 'monthly' ? periodYears : undefined,
      proposalTarget: modelOption === 'one-time' ? proposalTarget : undefined,
      bankName: selectedBank,
      virtualAccount: randomVA,
      invoiceNumber: invoiceNum
    });

    setPaymentStep('paying');
    setShowInvoiceModal(true);
  };

  const handleConfirmSimulatedPayment = () => {
    if (!invoiceData) return;

    // Trigger adding to App wide global state
    const donorData: Omit<Donor, 'id' | 'history'> = {
      name: invoiceData.name,
      phone: invoiceData.phone,
      email: `${invoiceData.name.toLowerCase().replace(/\s+/g, '')}@gmail.com`, // Auto generated email for compatibility
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80',
      type: invoiceData.type,
      status: invoiceData.type === 'monthly' ? 'active' : 'inactive',
      totalContribution: invoiceData.amount, // Set original initial contribution
      monthlyCommitment: invoiceData.monthlyCommitment,
      periodYears: invoiceData.periodYears,
      monthsPaid: invoiceData.type === 'monthly' ? 1 : undefined,
      totalMonthsCommit: invoiceData.type === 'monthly' ? (invoiceData.periodYears! * 12) : undefined,
      lastPaymentDate: new Date().toISOString()
    };

    const record: Omit<DonationRecord, 'id' | 'invoiceNumber' | 'status'> = {
      amount: invoiceData.amount,
      date: new Date().toISOString(),
      type: invoiceData.type,
      description: invoiceData.type === 'monthly' 
        ? `Iuran Bulanan Masjid An-Nur - Bulan Ke-1 (Plan ${invoiceData.periodYears} Thn)`
        : `Donasi Sekali Bayar - Alokasi: ${proposals.find(p => p.id === invoiceData.proposalTarget)?.title || 'Urgent List'}`
    };

    onAddDonation(donorData, invoiceData.amount, record);
    setPaymentStep('success');
  };

  const formattedRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(val);
  };

  const formatRupiahInput = (num: number | string) => {
    if (num === undefined || num === null || num === 0) return '';
    const str = String(num).replace(/\D/g, '');
    if (!str) return '';
    return new Intl.NumberFormat('id-ID').format(Number(str));
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* 1. CHART AREA (Grafik Capaian Dana) */}
      <div className="p-4 bg-white border-b border-sage/10 space-y-3.5 select-none shrink-0">
        <div className="flex justify-between items-baseline">
          <div>
            <span className="text-[10px] text-deep bg-sage/20 border border-sage/30 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
              Grafik Capaian Dana
            </span>
            <h2 className="serif text-sm font-bold text-deep mt-1">Akumulasi Swadaya & Donatur</h2>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-400 block">Target Pembangunan</span>
            <span className="text-sm font-bold font-mono text-slate-900">{formattedRupiah(totalTarget)}</span>
          </div>
        </div>

        {/* Big Progress ring & Bar Combo Card */}
        <div className="relative bg-gradient-to-br from-deep to-olive text-white rounded-3xl p-4 card-shadow space-y-4 overflow-hidden">
          <div className="absolute right-0 bottom-0 opacity-10 translate-x-4 translate-y-4 scale-120">
            <Gift size={140} />
          </div>

          <div className="grid grid-cols-2 gap-2 relative">
            <div>
              <span className="text-[10px] text-sage block uppercase tracking-wider font-semibold">Dana Terkumpul</span>
              <span className="text-lg font-extrabold font-mono leading-none block mt-1">{formattedRupiah(totalCollected)}</span>
              <span className="text-[10px] text-cream opacity-90 mt-1 block">
                Mencakup {progressPercent.toFixed(1)}% dari total target pembangunan fisik masjid.
              </span>
            </div>
            
            <div className="flex flex-col items-end justify-center">
              <span className="text-[10px] text-sage uppercase tracking-wider block font-semibold">Kekurangan Dana</span>
              <span className="text-sm font-bold font-mono text-amber-300 block mt-0.5">{formattedRupiah(remainingNeeded)}</span>
              <span className="text-[9px] bg-white/10 px-1.5 py-0.5 rounded-full mt-2 border border-white/10">
                Peluang Amal Jariyah
              </span>
            </div>
          </div>

          {/* Gorgeous Horizontal Segmented Progress Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] font-semibold text-cream">
              <span>Fundraising Progression</span>
              <span className="text-amber-300 font-mono text-xs">{progressPercent.toFixed(1)}% target selesai</span>
            </div>
            <div className="h-3 bg-white/15 rounded-full p-0.5 border border-white/5 relative overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-amber-300 rounded-full shadow-inner animate-pulse transition-all duration-1000"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Micro SVG Area Chart for Visual Polish */}
          <div className="bg-white/5 p-2 rounded-2xl border border-white/10 flex items-center gap-3">
            <div className="h-8 w-12 flex items-end">
              <svg className="w-full h-full text-amber-300/80 overflow-visible" viewBox="0 0 100 40">
                <path
                  d="M0 40 Q25 35 50 20 T100 12 L100 40 Z"
                  fill="currentColor"
                  fillOpacity="0.2"
                />
                <path
                  d="M0 40 Q25 35 50 20 T100 12"
                  stroke="currentColor"
                  strokeWidth="2"
                  fill="none"
                />
                <circle cx="100" cy="12" r="3" fill="#FFF" />
              </svg>
            </div>
            <div className="flex-1 text-[10px] text-cream leading-tight">
              <span className="font-bold text-amber-200">Tren Sumbangan 30 Hari Terakhir</span>: 
              Terjadi peningkatan partisipasi iuran bulanan dari penghuni perumahan baru blok C-D.
            </div>
          </div>
        </div>
      </div>

      {/* 2. FORM AREA & SELECTION */}
      <div className="p-4 space-y-4 flex-1">
        {/* Title explanation */}
        <div className="text-center select-none">
          <h3 className="serif font-bold text-xs text-deep">PARTISIPASI MODEL PENDANAAN MASJID AN-NUR</h3>
          <p className="text-[11px] text-slate-500 mt-0.5">Silakan pilih cara berdonasi yang paling sesuai untuk Anda</p>
        </div>

        {/* Tab model toggle */}
        <div className="grid grid-cols-2 gap-2 bg-sage/10 border border-sage/20 p-1 rounded-2xl select-none">
          <button
            onClick={() => setModelOption('one-time')}
            id="donation-once-tab"
            className={`py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              modelOption === 'one-time'
                ? 'bg-white text-deep shadow-sm'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Donasi Sekali Bayar
            <span className="block text-[8px] font-semibold text-amber-600 mt-0.5">Untuk Kebutuhan Mendesak</span>
          </button>
          <button
            onClick={() => setModelOption('monthly')}
            id="donation-monthly-tab"
            className={`py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              modelOption === 'monthly'
                ? 'bg-white text-deep shadow-sm'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Iuran Bulanan (Years)
            <span className="block text-[8px] font-semibold text-olive mt-0.5">Komitmen Jangka Panjang</span>
          </button>
        </div>

        <form onSubmit={handleCreateDonationInvoice} className="bg-white border border-sage/10 card-shadow rounded-3xl p-4 space-y-4">
          <div className="flex items-center gap-2 text-deep font-bold text-xs border-b border-sage/10 pb-2 select-none">
            <Heart size={14} className="text-amber-500 fill-amber-500" />
            <h3 className="serif">{modelOption === 'one-time' ? 'DONASI SEKALI BAYAR' : 'KOMITMEN IURAN BULANAN'}</h3>
          </div>

          {/* Common Fields Name & Email */}
          <div className="grid grid-cols-1 gap-3 text-xs">
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
                Nama Donatur (Lengkap)
              </label>
              <input
                type="text"
                required
                placeholder="Contoh: Amiruddin Asrul..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 focus:border-deep rounded-xl bg-slate-50 focus:bg-white focus:outline-none transition-all text-slate-700"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
                Nomor HP / WhatsApp (Aktif)
              </label>
              <input
                type="tel"
                required
                placeholder="Contoh: 081234567xxx..."
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 focus:border-deep rounded-xl bg-slate-50 focus:bg-white focus:outline-none transition-all text-slate-700 font-mono"
              />
            </div>
          </div>

          {/* Model Option 1: Monthly Years commit */}
          {modelOption === 'monthly' && (
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
                  Durasi Komitmen Iuran
                </label>
                <div className="grid grid-cols-5 gap-1 text-center font-mono">
                  {[1, 2, 3, 4, 5].map((y) => (
                    <button
                      key={y}
                      type="button"
                      onClick={() => setPeriodYears(y)}
                      className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        periodYears === y
                          ? 'bg-sage/10 border-olive text-deep'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {y} <span className="block text-[7px] uppercase font-sans mt-0.5">Tahun</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[10px] uppercase font-bold text-slate-500 mb-1">
                  <span>Sumbangan Bulanan</span>
                  <span className="font-mono text-deep font-bold">{formattedRupiah(monthlyCommitment)}</span>
                </div>
                <input
                  type="range"
                  min="50000"
                  max="5000000"
                  step="50000"
                  value={monthlyCommitment}
                  onChange={(e) => setMonthlyCommitment(Number(e.target.value))}
                  className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-deep"
                />
                
                {/* Fast Selector */}
                <div className="flex gap-1.5 overflow-x-auto py-1 scrollbar-none select-none mt-1 font-mono">
                  {QUICK_MONTHLY_AMOUNTS.map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setMonthlyCommitment(amt)}
                      className={`px-2 py-1 text-[10px] font-bold rounded-lg border shrink-0 transition-colors cursor-pointer ${
                        monthlyCommitment === amt
                          ? 'bg-deep text-white border-deep'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {amt >= 1000000 ? `${amt / 1000000} Jt` : `${amt / 1000} Rb`}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-sage/10 p-3 rounded-2xl border border-sage/20 space-y-1 select-none">
                <span className="text-[9px] uppercase font-extrabold text-deep tracking-wider block font-bold">Kalkulator Komitmen Jasa Amal</span>
                <div className="flex justify-between font-medium text-xs text-slate-700">
                  <span>Kontribusi Per Bulan:</span>
                  <span className="font-bold">{formattedRupiah(monthlyCommitment)}</span>
                </div>
                <div className="flex justify-between font-medium text-xs text-slate-700">
                  <span>Durasi Pembayaran:</span>
                  <span className="font-bold">{periodYears} Tahun ({periodYears * 12} bulan)</span>
                </div>
                <div className="h-px bg-slate-250/50 my-1" />
                <div className="flex justify-between font-bold text-xs text-deep">
                  <span>Total Amal di Masa Depan:</span>
                  <span className="font-mono text-sm">{formattedRupiah(monthlyCommitment * 12 * periodYears)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Model Option 2: One-time for urgent need */}
          {modelOption === 'one-time' && (
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
                  Disalurkan Untuk Rencana Alokasi
                </label>
                <select
                  value={proposalTarget}
                  onChange={(e) => setProposalTarget(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 focus:border-deep rounded-xl bg-slate-50 text-xs focus:outline-none transition-all text-slate-700"
                >
                  {proposals.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} ({p.urgency})
                    </option>
                  ))}
                  <option value="kas-umum">Kas Umum Sarpras Masjid (Urgent / Fleksibel)</option>
                </select>
              </div>

              <div>
                <div className="flex justify-between text-[10px] uppercase font-bold text-slate-500 mb-1">
                  <span>Jumlah Donasi Seikhlasnya</span>
                  <span className="font-mono text-deep font-bold">{formattedRupiah(amount)}</span>
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  value={formatRupiahInput(amount)}
                  onChange={(e) => {
                    const rawNum = e.target.value.replace(/\D/g, '');
                    setAmount(rawNum === '' ? 0 : Number(rawNum));
                  }}
                  className="w-full px-3 py-2 border border-slate-200 focus:border-deep rounded-xl bg-slate-50 font-mono text-xs focus:outline-none transition-all text-slate-700"
                />

                {/* Quick select buttons */}
                <div className="flex gap-1.5 overflow-x-auto py-1 scrollbar-none select-none mt-2 font-mono">
                  {QUICK_SINGLE_AMOUNTS.map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setAmount(amt)}
                      className={`px-2 py-1 text-[10px] font-bold rounded-lg border shrink-0 transition-colors cursor-pointer ${
                        amount === amt
                          ? 'bg-deep text-white border-deep'
                          : 'bg-slate-50 hover:bg-slate-105 text-slate-600 border-slate-200'
                      }`}
                    >
                      {formattedRupiah(amt)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Payment Method Selector */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1.5">
              Pilihan Gerbang Pembayaran
            </label>
            <div className="grid grid-cols-3 gap-1.5 text-center">
              {[
                { name: 'MANDIRI', label: 'Mandiri VA' },
                { name: 'BCA', label: 'BCA Virtual' },
                { name: 'QRIS', label: 'QRIS Instan' }
              ].map((b) => (
                <button
                  key={b.name}
                  type="button"
                  onClick={() => setSelectedBank(b.name)}
                  className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    selectedBank === b.name
                      ? 'bg-sage/10 border-olive text-deep shadow-xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {b.name === 'QRIS' ? <QrCode size={16} /> : <Landmark size={16} />}
                  <span>{b.label}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            id="donation-submit-btn"
            className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-2xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs hover:shadow active:scale-[0.99] transition-all"
          >
            Ikat Niat, Siapkan Donasi
            <ArrowRight size={14} />
          </button>
        </form>
      </div>

      {/* 3. INVOICE POPUP OR MODAL */}
      {showInvoiceModal && invoiceData && (
        <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="w-full max-w-[360px] bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-4 flex justify-between items-center select-none">
              <span className="text-xs text-slate-400 font-mono tracking-tight">{invoiceData.invoiceNumber}</span>
              <span className="bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase animate-pulse">
                Menunggu Pembayaran
              </span>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4">
              {paymentStep === 'paying' ? (
                <div className="space-y-3.5">
                  <div className="text-center">
                    <span className="text-xs text-slate-400 block uppercase font-bold tracking-wider">Total Donasi Anda</span>
                    <span className="text-xl font-extrabold font-mono text-deep mt-1 block">
                      {formattedRupiah(invoiceData.amount)}
                    </span>
                    {invoiceData.type === 'monthly' && (
                      <span className="text-[10px] text-olive font-medium block mt-1">
                        *Laporan iuran ke-1 dari rencana kontribusi {invoiceData.periodYears} Tahun
                      </span>
                    )}
                  </div>

                  <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 flex items-center gap-3">
                    <div className="h-10 w-10 bg-white border rounded-xl flex items-center justify-center shadow-xs text-deep shrink-0 select-none">
                      {invoiceData.bankName === 'QRIS' ? <QrCode size={20} /> : <Landmark size={20} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block">Metode Pembayaran</span>
                      <strong className="text-xs text-slate-800">
                        {invoiceData.bankName === 'QRIS' ? 'QRIS DYNAMIC DIGITAL' : `${invoiceData.bankName} VIRTUAL ACCOUNT`}
                      </strong>
                    </div>
                  </div>

                  {invoiceData.bankName === 'QRIS' ? (
                    <div className="flex flex-col items-center justify-center p-3 bg-white border rounded-2xl space-y-2 select-none">
                      <div className="relative h-32 w-32 bg-slate-100 border p-1 rounded-lg">
                        {/* Custom QR Code Simulation */}
                        <div className="absolute inset-0.5 bg-[repeating-linear-gradient(45deg,#334155,#334155_6px,#FFF_6px,#FFF_12px)] opacity-95 rounded" />
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white p-1 rounded-sm border">
                          <div className="h-6 w-6 bg-emerald-800 rounded flex items-center justify-center text-white font-serif italic text-[10px] font-bold">N</div>
                        </div>
                      </div>
                      <span className="text-[9px] text-slate-400 uppercase font-bold">Pindai kode QRIS diatas dengan M-Banking / E-Wallet</span>
                    </div>
                  ) : (
                    <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 space-y-2 select-none">
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block">Nomor Virtual Account</span>
                      <div className="flex justify-between items-center bg-white p-2 rounded-xl border border-slate-200">
                        <code className="text-xs font-mono font-bold text-slate-800 tracking-wider">
                          {invoiceData.virtualAccount.replace(/(.{4})/g, '$1 ')}
                        </code>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(invoiceData.virtualAccount);
                          }}
                          className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-600 hover:text-emerald-800 hover:bg-emerald-50 cursor-pointer font-bold"
                        >
                          Salin
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="p-3 bg-amber-500/5 text-[10px] text-slate-600 border border-amber-500/10 rounded-2xl leading-relaxed">
                    <strong className="text-slate-800 font-bold block">💡 Panduan Simulasi:</strong>
                    Aplikasi ini berjalan dalam sistem kotak pasir (sandbox preview). Cukup klik tombol <strong>"Bayar Sukses (Simulasi)"</strong> di bawah ini untuk meneruskan audit uang donasi masuk. No real money needed.
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setShowInvoiceModal(false)}
                      className="flex-1 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-600 font-medium rounded-xl text-xs cursor-pointer text-center"
                    >
                      Batal
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmSimulatedPayment}
                      id="confirm-pay-btn"
                      className="flex-1 py-1.5 bg-olive hover:bg-deep text-white font-bold rounded-xl text-xs cursor-pointer shadow active:scale-95 transition-all text-center"
                    >
                      Bayar Sukses (Simulasi)
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 text-center py-2 animate-fade-in select-none">
                  <div className="h-14 w-14 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 mx-auto border border-emerald-100">
                    <CheckCircle2 size={36} className="text-emerald-600" />
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="serif font-extrabold text-sm text-emerald-800 leading-snug">
                      TERIMA KASIH ATAS DONASI ANDA!
                    </h4>
                    <p className="text-[11px] text-slate-600 px-1 leading-relaxed">
                      Kami akan meluncurkan proses verifikasi terhadap dana yang ditransfer masuk ke rekening Panitia Pembangunan Masjid An-Nur demi menjaga transparansi pengelolaan dana jemaah. Jazakumullahu Khairan Katsiran.
                    </p>
                  </div>

                  <div className="text-left bg-slate-50 p-3 rounded-2xl border border-slate-100 text-[11px] space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Invoice Ref:</span>
                      <strong className="font-mono text-slate-700">{invoiceData.invoiceNumber}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Donatur:</span>
                      <strong className="text-slate-700">{invoiceData.name}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Jumlah Dana:</span>
                      <strong className="text-emerald-700 font-bold">{formattedRupiah(invoiceData.amount)}</strong>
                    </div>
                    <div className="flex justify-between border-t border-dashed border-slate-200 pt-1 mt-1">
                      <span className="text-slate-400">Status Pembukuan:</span>
                      <span className="bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-black uppercase text-[8.5px]">
                        Sedang Diverifikasi
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 pt-1 font-bold">
                    <a
                      href={`https://wa.me/6281242337750?text=Assalamu%27alaikum%20Panitia%20Pembangunan%20Masjid%20An-Nur.%20Saya%20${encodeURIComponent(invoiceData.name)}%20ingin%20mengirimkan%20bukti%20transfer%20donasi%20sebesar%20${encodeURIComponent(formattedRupiah(invoiceData.amount))}%20untuk%20invoice%20${encodeURIComponent(invoiceData.invoiceNumber)}.`}
                      target="_blank"
                      rel="noreferrer"
                      className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs cursor-pointer shadow flex items-center justify-center gap-1.5 transition-all text-center leading-normal"
                    >
                      <Send size={13} className="stroke-[2.5px]" />
                      <span>Kirim Bukti Transfer (WhatsApp)</span>
                    </a>

                    <button
                      type="button"
                      onClick={() => {
                        setShowInvoiceModal(false);
                        // Reset Billing form values
                        setName('');
                        setPhone('');
                        setAmount(500000);
                        setPaymentStep('billing');
                      }}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs cursor-pointer text-center"
                    >
                      Tutup & Kembali
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
