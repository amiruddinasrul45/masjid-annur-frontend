/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Donor, ProgressReport, Allocation, Disbursement, Proposal, AppNotification, DonationRecord, ActivityGallery } from './types';
import {
  INITIAL_PROPOSALS,
  INITIAL_ALLOCATIONS,
  INITIAL_DISBURSEMENTS,
  INITIAL_PROGRESS_REPORTS,
  INITIAL_GALLERY,
  INITIAL_NOTIFICATIONS,
  INITIAL_DONORS
} from './mockData';

import { Logo } from './components/Logo';
import { MobileFrame } from './components/MobileFrame';
import { ProgressTab } from './components/ProgressTab';
import { DonationTab } from './components/DonationTab';
import { ProposalTab } from './components/ProposalTab';
import { GalleryTab } from './components/GalleryTab';
import { MapsTab } from './components/MapsTab';
import { TransparencyTab } from './components/TransparencyTab';
import { PanitiaPanel } from './components/PanitiaPanel';

import { 
  Building, 
  Coins, 
  MapPin, 
  ArrowRight, 
  Calendar, 
  Clock, 
  HardHat, 
  CheckCircle2, 
  Flame, 
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  UserCheck,
  X,
  Lock
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('beranda');

  // Core App States (fully persistent)
  const [donors, setDonors] = useState<Donor[]>([]);
  const [progressReports, setProgressReports] = useState<ProgressReport[]>([]);
  const [allocations, setAllocations] = useState<Allocation[]>([]);
  const [disbursements, setDisbursements] = useState<Disbursement[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [gallery, setGallery] = useState<ActivityGallery[]>([]);
  const [activeProposalId, setActiveProposalId] = useState<string>('p2');

  // Custom states for system statistics & specifications
  const [totalTarget, setTotalTarget] = useState<number>(1500000000);
  const [basePhysicalProgress, setBasePhysicalProgress] = useState<number>(74);
  const [oldMosquePhotos, setOldMosquePhotos] = useState<Array<{ id: string; url: string; label: string }>>([
    {
      id: 'old_1',
      url: 'https://images.unsplash.com/photo-1590076211181-4351cddc290c?auto=format&fit=crop&w=600&q=80',
      label: 'Atap Lapuk & Keretakan Struktur Depan'
    },
    {
      id: 'old_2',
      url: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=600&q=80',
      label: 'Kondisi Sisi Tembok Mihrab Lama'
    },
    {
      id: 'old_3',
      url: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=600&q=80',
      label: 'Penyangga Tiang yang Retak Serius'
    },
    {
      id: 'old_4',
      url: 'https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?auto=format&fit=crop&w=600&q=80',
      label: 'Sistem Sanitasi/Tempat Wudhu Lama'
    }
  ]);
  const [mosqueSpecs, setMosqueSpecs] = useState({
    luasTanah: 167,
    luasBangunan: 158,
    area: 'Area Fasos Fasum Perumahan Bumi Daya Indah',
    alamat: 'Jl. Bumi Daya Raya No. 42 (Area Fasos-Fasum RT 04 / RW 12), Perumahan Bumi Daya Indah, Tambun Selatan, Bekasi - Jawa Barat',
    koordinat: '-6.28452, 106.91428'
  });

  // Panitia/Committee Admin Session States
  const [isPanitiaLoggedIn, setIsPanitiaLoggedIn] = useState<boolean>(false);
  const [showMoreSpecs, setShowMoreSpecs] = useState<boolean>(false);
  const [currentOldPhotoIndex, setCurrentOldPhotoIndex] = useState<number>(0);

  // Auto shift slides for old photos
  useEffect(() => {
    if (oldMosquePhotos.length === 0) return;
    const slideTimer = setInterval(() => {
      setCurrentOldPhotoIndex((prev) => (prev + 1) % oldMosquePhotos.length);
    }, 3800);
    return () => clearInterval(slideTimer);
  }, [oldMosquePhotos]);

  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Load from LocalStorage on mount
  useEffect(() => {
    const localDonors = localStorage.getItem('annur_donors');
    const localProgress = localStorage.getItem('annur_progress');
    const localAllocations = localStorage.getItem('annur_allocations');
    const localDisbursements = localStorage.getItem('annur_disbursements');
    const localProposals = localStorage.getItem('annur_proposals');
    const localNotifications = localStorage.getItem('annur_notifications');
    const localGallery = localStorage.getItem('annur_gallery');

    if (localDonors) {
      const parsedDonors = JSON.parse(localDonors);
      const hasSwadayaBase = parsedDonors.some((d: any) => d.id === 'swadaya_base');
      if (!hasSwadayaBase) {
        const swadayaDonor = {
          id: 'swadaya_base',
          name: 'Dana Swadaya Awal Masjid An-Nur',
          email: 'panitia.annur@gmail.com',
          phone: '081100000000',
          avatar: 'https://images.unsplash.com/photo-1590076211181-4351cddc290c?auto=format&fit=crop&w=150&h=150&q=80',
          type: 'one-time',
          status: 'inactive',
          totalContribution: 250000000,
          history: [
            { id: 'dh_base_1', amount: 250000000, date: '2026-04-01', type: 'one-time', description: 'Dana Kas Awal Swadaya Pengurus & Jamaah Bumi Daya Indah', invoiceNumber: 'INV/SWD/2026/04/001', status: 'sukses' }
          ]
        };
        const migrated = [swadayaDonor, ...parsedDonors];
        setDonors(migrated);
        localStorage.setItem('annur_donors', JSON.stringify(migrated));
      } else {
        setDonors(parsedDonors);
      }
    } else {
      setDonors(INITIAL_DONORS);
      localStorage.setItem('annur_donors', JSON.stringify(INITIAL_DONORS));
    }

    if (localProgress) setProgressReports(JSON.parse(localProgress));
    else {
      setProgressReports(INITIAL_PROGRESS_REPORTS);
      localStorage.setItem('annur_progress', JSON.stringify(INITIAL_PROGRESS_REPORTS));
    }

    if (localAllocations) setAllocations(JSON.parse(localAllocations));
    else {
      setAllocations(INITIAL_ALLOCATIONS);
      localStorage.setItem('annur_allocations', JSON.stringify(INITIAL_ALLOCATIONS));
    }

    if (localDisbursements) setDisbursements(JSON.parse(localDisbursements));
    else {
      setDisbursements(INITIAL_DISBURSEMENTS);
      localStorage.setItem('annur_disbursements', JSON.stringify(INITIAL_DISBURSEMENTS));
    }

    if (localProposals) setProposals(JSON.parse(localProposals));
    else {
      setProposals(INITIAL_PROPOSALS);
      localStorage.setItem('annur_proposals', JSON.stringify(INITIAL_PROPOSALS));
    }

    if (localNotifications) setNotifications(JSON.parse(localNotifications));
    else {
      setNotifications(INITIAL_NOTIFICATIONS);
      localStorage.setItem('annur_notifications', JSON.stringify(INITIAL_NOTIFICATIONS));
    }

    if (localGallery) setGallery(JSON.parse(localGallery));
    else {
      setGallery(INITIAL_GALLERY);
      localStorage.setItem('annur_gallery', JSON.stringify(INITIAL_GALLERY));
    }

    const localTotalTarget = localStorage.getItem('annur_total_target');
    const localBasePhys = localStorage.getItem('annur_base_phys');
    const localOldPhotos = localStorage.getItem('annur_old_photos');
    const localSpecs = localStorage.getItem('annur_specs');

    if (localTotalTarget) setTotalTarget(Number(localTotalTarget));
    if (localBasePhys) setBasePhysicalProgress(Number(localBasePhys));
    if (localOldPhotos) setOldMosquePhotos(JSON.parse(localOldPhotos));
    if (localSpecs) setMosqueSpecs(JSON.parse(localSpecs));
  }, []);

  // Sync to localstorage helper
  const syncToStorage = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // Financial Calculations
  const swadayaBase = 0;   // Set to 0 because self-funded cash is now transparently loaded in INITIAL_DONORS!

  // Sum only APPROVED ('sukses') donation records
  const totalCollected = swadayaBase + donors.reduce((sum, d) => {
    const approvedSum = d.history
      .filter(h => h.status === 'sukses')
      .reduce((s, h) => s + h.amount, 0);
    return sum + approvedSum;
  }, 0);
  const totalSpent = disbursements.reduce((sum, d) => sum + d.amount, 0);

  // Calculate physical progress %
  // Sederhana: physical completion correlates to resolved tasks and report counts
  const addReportBonus = progressReports.length > INITIAL_PROGRESS_REPORTS.length
    ? (progressReports.length - INITIAL_PROGRESS_REPORTS.length) * 1.5
    : 0;
  const physicalProgress = Math.min(basePhysicalProgress + addReportBonus, 100);

  // 1. HANDLER: TAMBAH LAPORAN PROGRES HARIAN
  const handleAddProgressReport = (newReport: Omit<ProgressReport, 'id' | 'date'>) => {
    const report: ProgressReport = {
      ...newReport,
      id: `prog_new_${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };

    const updated = [report, ...progressReports];
    setProgressReports(updated);
    syncToStorage('annur_progress', updated);

    // Trigger Notification
    const notif: AppNotification = {
      id: `notif_prog_${Date.now()}`,
      title: 'Laporan Progres Harian Baru',
      message: `Update progres Sektor ${report.category}: "${report.title}" dilaporkan selesai ${report.percentageAfter}%.`,
      time: 'Baru saja',
      isRead: false,
      type: 'progress'
    };

    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    syncToStorage('annur_notifications', updatedNotifs);
  };

  // 2. HANDLER: TAMBAH DONASI BARU (Pilihan 1 / Pilihan 2) - INITIAL STATUS AS 'PROSES' UNTIL PANEL PANITIA DIRECTS APPROVAL
  const handleAddDonation = (
    donorData: Omit<Donor, 'id' | 'history'>,
    amount: number,
    record: Omit<DonationRecord, 'id' | 'invoiceNumber' | 'status'>
  ) => {
    const timestampId = Date.now().toString();
    const invoiceNumber = `INV/OBN/2026/05/${timestampId.slice(-4)}`;
    
    const formattedName = donorData.name
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

    const formattedDonorData = {
      ...donorData,
      name: formattedName
    };

    const newRecord: DonationRecord = {
      ...record,
      id: `rc_${timestampId}`,
      invoiceNumber,
      status: 'proses' // Default state until confirmed by panitia
    };

    // Check if donor exists
    const existingIndex = donors.findIndex(d => {
      const emailMatch = d.email && d.email.toLowerCase() === (formattedDonorData.email || '').toLowerCase();
      const phoneMatch = d.phone && d.phone === formattedDonorData.phone;
      return !!(emailMatch || phoneMatch);
    });
    
    let updatedDonors = [...donors];

    if (existingIndex !== -1) {
      // Existing Donor: update history only (do NOT update totalContribution yet until approved)
      const existing = updatedDonors[existingIndex];
      updatedDonors[existingIndex] = {
        ...existing,
        history: [newRecord, ...existing.history]
      };
    } else {
      // New Donor: set totalContribution to 0 because money is still in pending process
      const newDonor: Donor = {
        ...formattedDonorData,
        id: `d_new_${timestampId}`,
        totalContribution: 0,
        status: formattedDonorData.type === 'monthly' ? 'inactive' : 'inactive', // Stay inactive until first payment approved
        history: [newRecord]
      };
      updatedDonors = [newDonor, ...updatedDonors];
    }

    setDonors(updatedDonors);
    syncToStorage('annur_donors', updatedDonors);

    // Trigger push notification about waiting verification
    const notif: AppNotification = {
      id: `notif_don_${Date.now()}`,
      title: 'Menunggu Verifikasi Pembayaran',
      message: `Alhamdulillah, transfer senilai ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(amount)} dari ${donorData.name} telah dikirim ke sistem. Menanti persetujuan Panitia.`,
      time: 'Baru saja',
      isRead: false,
      type: 'donation'
    };

    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    syncToStorage('annur_notifications', updatedNotifs);
  };

  // 3. HANDLER: PENYALURAN DANA KE BENEFICIARY (ADMIN DISBURSE)
  const handleAddDisbursement = (newDisb: Omit<Disbursement, 'id' | 'date' | 'status'>) => {
    const disb: Disbursement = {
      ...newDisb,
      id: `disb_new_${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      status: 'Disalurkan'
    };

    const updatedDisb = [...disbursements, disb];
    setDisbursements(updatedDisb);
    syncToStorage('annur_disbursements', updatedDisb);

    // Deduct / update in allocations
    const updatedAllocations = allocations.map(a => {
      if (disb.purpose.toLowerCase().includes(a.item.toLowerCase()) || a.category === disb.category) {
        const potentialSpent = a.actualSpent + disb.amount;
        return {
          ...a,
          actualSpent: potentialSpent,
          status: potentialSpent >= a.estimatedCost ? ('Selesai' as const) : ('Pengerjaan' as const)
        };
      }
      return a;
    });
    setAllocations(updatedAllocations);
    syncToStorage('annur_allocations', updatedAllocations);

    // TRIGER NOTIFIKASI OTOMATIS SAAT DANA DISALURKAN
    const formattedAmt = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(disb.amount);
    const notif: AppNotification = {
      id: `notif_out_${Date.now()}`,
      title: 'Penyaluran Dana Berhasil',
      message: `Dana Amanah umat sebesar ${formattedAmt} telah disalurkan kepada "${disb.recipient}" untuk keperluan: ${disb.purpose}. Laporan penggunaan dana real-time terbukti akuntabel.`,
      time: 'Baru saja',
      isRead: false,
      type: 'disbursement',
      metadata: {
        itemId: disb.id,
        amount: disb.amount,
        recipient: disb.recipient
      }
    };

    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    syncToStorage('annur_notifications', updatedNotifs);
  };

  // 4. HANDLER: PEMBAYARAN IURAN AKTIF BULANAN BERIKUTNYA
  const handleAddDonorPayment = (donorId: string, paymentRecord: DonationRecord) => {
    const updatedDonors = donors.map(d => {
      if (d.id === donorId) {
        const nextPaid = (d.monthsPaid || 0) + 1;
        return {
          ...d,
          monthsPaid: nextPaid,
          totalContribution: d.totalContribution + paymentRecord.amount,
          history: [paymentRecord, ...d.history],
          lastPaymentDate: paymentRecord.date
        };
      }
      return d;
    });

    setDonors(updatedDonors);
    syncToStorage('annur_donors', updatedDonors);

    // Push notification
    const formattedAmt = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(paymentRecord.amount);
    const donorObj = donors.find(d => d.id === donorId);
    
    const notif: AppNotification = {
      id: `notif_pay_${Date.now()}`,
      title: 'Iuran Bulanan Sukses',
      message: `Setoran iuran ${paymentRecord.description.split('-')[1]} senilai ${formattedAmt} dari donatur ${donorObj?.name || 'Swadaya'} telah terverifikasi dalam kas pembangunan.`,
      time: 'Baru saja',
      isRead: false,
      type: 'donation'
    };

    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    syncToStorage('annur_notifications', updatedNotifs);
  };

  // 5. HANDLER: PANITIA APPROVE DONATION
  const handleApproveDonation = (donorId: string, recordId: string) => {
    let approvedAmount = 0;
    let donorName = '';
    let recordDesc = '';

    const updatedDonors = donors.map(d => {
      if (d.id === donorId) {
        donorName = d.name;
        const updatedHistory = d.history.map(h => {
          if (h.id === recordId && h.status === 'proses') {
            approvedAmount = h.amount;
            recordDesc = h.description;
            return { ...h, status: 'sukses' as const };
          }
          return h;
        });

        const isNowActive = d.type === 'monthly' ? 'active' as const : d.status;
        const addMonths = d.type === 'monthly' ? 1 : 0;

        return {
          ...d,
          status: isNowActive,
          monthsPaid: (d.monthsPaid || 0) + addMonths,
          totalContribution: d.totalContribution + approvedAmount,
          lastPaymentDate: approvedAmount > 0 ? new Date().toISOString().split('T')[0] : d.lastPaymentDate,
          history: updatedHistory
        };
      }
      return d;
    });

    setDonors(updatedDonors);
    syncToStorage('annur_donors', updatedDonors);

    if (approvedAmount > 0) {
      // also update proposal collected if targeted
      if (recordDesc.includes('Alokasi:') && proposals.length > 0) {
        const updatedProposals = proposals.map(p => {
          if (recordDesc.includes(p.title)) {
            const potentialCol = Math.min(p.currentCollected + approvedAmount, p.targetCost);
            return {
              ...p,
              currentCollected: potentialCol,
              status: (potentialCol >= p.targetCost) ? ('Terpenuhi' as const) : p.status
            };
          }
          return p;
        });
        setProposals(updatedProposals);
        syncToStorage('annur_proposals', updatedProposals);
      }

      // Trigger push notification
      const notif: AppNotification = {
        id: `notif_don_approved_${Date.now()}`,
        title: 'Donasi Terima & Diverifikasi',
        message: `Alhamdulillah, dana sebesar ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(approvedAmount)} dari ${donorName} telah DITERIMA & DISAHKAN oleh Panitia Pembangunan Masjid An-Nur. Syukran Katsiran!`,
        time: 'Baru saja',
        isRead: false,
        type: 'donation'
      };

      const updatedNotifs = [notif, ...notifications];
      setNotifications(updatedNotifs);
      syncToStorage('annur_notifications', updatedNotifs);
    }
  };

  // 6. HANDLER: TAMBAH DOKUMENTASI KEGIATAN BARU
  const handleAddGalleryItem = (newItem: Omit<ActivityGallery, 'id' | 'date'>) => {
    const item: ActivityGallery = {
      ...newItem,
      id: `gal_new_${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    const updated = [item, ...gallery];
    setGallery(updated);
    syncToStorage('annur_gallery', updated);

    // Notification
    const notif: AppNotification = {
      id: `notif_gal_${Date.now()}`,
      title: 'Galeri Dokumentasi Baru',
      message: `Panitia mengunggah foto kegiatan baru: "${item.title}" kategori ${item.category}.`,
      time: 'Baru saja',
      isRead: false,
      type: 'info'
    };
    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    syncToStorage('annur_notifications', updatedNotifs);
  };

  // 7. HANDLER: TAMBAH PROGRAM PROPOSAL RAB BARU
  const handleAddProposal = (newProp: Omit<Proposal, 'id' | 'currentCollected' | 'status'>) => {
    const prop: Proposal = {
      ...newProp,
      id: `p_new_${Date.now()}`,
      currentCollected: 0,
      status: 'Aktif'
    };
    const updated = [...proposals, prop];
    setProposals(updated);
    syncToStorage('annur_proposals', updated);

    // Notification
    const notif: AppNotification = {
      id: `notif_prop_${Date.now()}`,
      title: 'Proposal RAB Baru Dibuka',
      message: `Sasaran RAB Baru: "${prop.title}" dengan usulan anggaran ${formattedRupiah(prop.targetCost)} untuk ${prop.category} telah terbit.`,
      time: 'Baru saja',
      isRead: false,
      type: 'info'
    };
    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    syncToStorage('annur_notifications', updatedNotifs);
  };

  // Clear or mark helper
  const handleMarkNotificationsAsRead = () => {
    const updated = notifications.map(n => ({ ...n, isRead: true }));
    setNotifications(updated);
    syncToStorage('annur_notifications', updated);
  };

  const handleClearNotification = (id: string) => {
    const updated = notifications.filter(n => n.id !== id);
    setNotifications(updated);
    syncToStorage('annur_notifications', updated);
  };

  const handleSelectProposalFromRAB = (id: string) => {
    setActiveProposalId(id);
    setActiveTab('donasi');
  };

  const formattedRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(val);
  };

  // Login verification handles for panitia
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginPassword.trim() === 'admin') {
      setIsPanitiaLoggedIn(true);
      setShowLoginModal(false);
      setLoginError(null);
      setLoginPassword('');
    } else {
      setLoginError('Sandi salah! Gunakan password sandbox: "admin"');
    }
  };

  const handleLogout = () => {
    setIsPanitiaLoggedIn(false);
  };

  const handleUpdateDonor = (donorId: string, fields: Partial<Donor>) => {
    let sanitizedFields = { ...fields };
    if (sanitizedFields.name) {
      sanitizedFields.name = sanitizedFields.name
        .toLowerCase()
        .split(/\s+/)
        .filter(Boolean)
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    }

    const updated = donors.map(d => {
      if (d.id === donorId) {
        let updatedHistory = d.history;
        let totalContribution = sanitizedFields.totalContribution !== undefined ? sanitizedFields.totalContribution : d.totalContribution;
        
        if (sanitizedFields.totalContribution !== undefined && d.history.length > 0) {
          updatedHistory = d.history.map((h, index) => {
            if (index === 0) {
              return { ...h, amount: sanitizedFields.totalContribution! };
            }
            return h;
          });
        }

        return {
          ...d,
          ...sanitizedFields,
          totalContribution,
          history: updatedHistory
        };
      }
      return d;
    });
    setDonors(updated);
    syncToStorage('annur_donors', updated);
  };

  const handleDeleteDonor = (donorId: string) => {
    const updated = donors.filter(d => d.id !== donorId);
    setDonors(updated);
    syncToStorage('annur_donors', updated);
  };

  const handleAddDonorManual = (newDonor: Donor) => {
    const formattedName = newDonor.name
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

    const titleCased = {
      ...newDonor,
      name: formattedName
    };
    const updated = [titleCased, ...donors];
    setDonors(updated);
    syncToStorage('annur_donors', updated);
  };

  const handleUpdateProgressReport = (id: string, fields: Partial<ProgressReport>) => {
    const updated = progressReports.map(r => r.id === id ? { ...r, ...fields } : r);
    setProgressReports(updated);
    syncToStorage('annur_progress', updated);
  };

  const handleDeleteProgressReport = (id: string) => {
    const updated = progressReports.filter(r => r.id !== id);
    setProgressReports(updated);
    syncToStorage('annur_progress', updated);
  };

  const handleUpdateAllocation = (id: string, fields: Partial<Allocation>) => {
    const updated = allocations.map(a => a.id === id ? { ...a, ...fields } : a);
    setAllocations(updated);
    syncToStorage('annur_allocations', updated);
  };

  const handleDeleteAllocation = (id: string) => {
    const updated = allocations.filter(a => a.id !== id);
    setAllocations(updated);
    syncToStorage('annur_allocations', updated);
  };

  const handleAddAllocation = (newAlloc: Omit<Allocation, 'id' | 'actualSpent'>) => {
    const alloc: Allocation = {
      ...newAlloc,
      id: `alloc_new_${Date.now()}`,
      actualSpent: 0
    };
    const updated = [...allocations, alloc];
    setAllocations(updated);
    syncToStorage('annur_allocations', updated);
  };

  const handleUpdateDisbursement = (id: string, fields: Partial<Disbursement>) => {
    const updated = disbursements.map(d => d.id === id ? { ...d, ...fields } : d);
    setDisbursements(updated);
    syncToStorage('annur_disbursements', updated);
  };

  const handleDeleteDisbursement = (id: string) => {
    const updated = disbursements.filter(d => d.id !== id);
    setDisbursements(updated);
    syncToStorage('annur_disbursements', updated);
  };

  const handleUpdateGalleryItem = (id: string, fields: Partial<ActivityGallery>) => {
    const updated = gallery.map(g => g.id === id ? { ...g, ...fields } : g);
    setGallery(updated);
    syncToStorage('annur_gallery', updated);
  };

  const handleDeleteGalleryItem = (id: string) => {
    const updated = gallery.filter(g => g.id !== id);
    setGallery(updated);
    syncToStorage('annur_gallery', updated);
  };

  const handleUpdateProposal = (id: string, fields: Partial<Proposal>) => {
    const updated = proposals.map(p => p.id === id ? { ...p, ...fields } : p);
    setProposals(updated);
    syncToStorage('annur_proposals', updated);
  };

  const handleDeleteProposal = (id: string) => {
    const updated = proposals.filter(p => p.id !== id);
    setProposals(updated);
    syncToStorage('annur_proposals', updated);
  };

  const handleUpdateSettings = (settings: {
    totalTarget?: number;
    basePhysicalProgress?: number;
    mosqueSpecs?: {
      luasTanah: number;
      luasBangunan: number;
      area: string;
      alamat: string;
      koordinat: string;
    };
    oldMosquePhotos?: Array<{ id: string; url: string; label: string }>;
  }) => {
    if (settings.totalTarget !== undefined) {
      setTotalTarget(settings.totalTarget);
      localStorage.setItem('annur_total_target', String(settings.totalTarget));
    }
    if (settings.basePhysicalProgress !== undefined) {
      setBasePhysicalProgress(settings.basePhysicalProgress);
      localStorage.setItem('annur_base_phys', String(settings.basePhysicalProgress));
    }
    if (settings.mosqueSpecs !== undefined) {
      setMosqueSpecs(settings.mosqueSpecs);
      localStorage.setItem('annur_specs', JSON.stringify(settings.mosqueSpecs));
    }
    if (settings.oldMosquePhotos !== undefined) {
      setOldMosquePhotos(settings.oldMosquePhotos);
      localStorage.setItem('annur_old_photos', JSON.stringify(settings.oldMosquePhotos));
    }
  };

  const handleUpdateDonorPayment = (donorId: string, paymentId: string, fields: Partial<DonationRecord>) => {
    const updated = donors.map(d => {
      if (d.id === donorId) {
        let diff = 0;
        const updatedHistory = d.history.map(h => {
          if (h.id === paymentId) {
            if (fields.amount !== undefined && h.status === 'sukses') {
              diff = fields.amount - h.amount;
            }
            return { ...h, ...fields };
          }
          return h;
        });
        return {
          ...d,
          totalContribution: d.totalContribution + diff,
          history: updatedHistory
        };
      }
      return d;
    });
    setDonors(updated);
    syncToStorage('annur_donors', updated);
  };

  const handleDeleteDonorPayment = (donorId: string, paymentId: string) => {
    const updated = donors.map(d => {
      if (d.id === donorId) {
        const record = d.history.find(h => h.id === paymentId);
        const amtToDeduct = (record && record.status === 'sukses') ? record.amount : 0;
        const updatedHistory = d.history.filter(h => h.id !== paymentId);
        const nextPaid = d.type === 'monthly' ? Math.max(0, (d.monthsPaid || 0) - 1) : d.monthsPaid;
        return {
          ...d,
          monthsPaid: nextPaid,
          totalContribution: Math.max(0, d.totalContribution - amtToDeduct),
          history: updatedHistory
        };
      }
      return d;
    });
    setDonors(updated);
    syncToStorage('annur_donors', updated);
  };

  const handleAccountClick = () => {
    if (isPanitiaLoggedIn) {
      setIsPanitiaLoggedIn(false); // Toggle to return to public view
    } else {
      setShowLoginModal(true);
    }
  };

  return (
    <MobileFrame
      activeTab={isPanitiaLoggedIn ? 'panitia' : activeTab}
      setActiveTab={isPanitiaLoggedIn ? () => {} : setActiveTab}
      notifications={notifications}
      onMarkNotificationsAsRead={handleMarkNotificationsAsRead}
      onClearNotification={handleClearNotification}
      onAccountClick={handleAccountClick}
      isPanitiaLoggedIn={isPanitiaLoggedIn}
    >
      {isPanitiaLoggedIn ? (
        <PanitiaPanel
          donors={donors}
          progressReports={progressReports}
          allocations={allocations}
          disbursements={disbursements}
          proposals={proposals}
          gallery={gallery}
          totalTarget={totalTarget}
          basePhysicalProgress={basePhysicalProgress}
          mosqueSpecs={mosqueSpecs}
          oldMosquePhotos={oldMosquePhotos}
          onAddProgressReport={handleAddProgressReport}
          onAddDisbursement={handleAddDisbursement}
          onAddGalleryItem={handleAddGalleryItem}
          onAddProposal={handleAddProposal}
          onApproveDonation={handleApproveDonation}
          onLogout={handleLogout}
          onUpdateDonor={handleUpdateDonor}
          onDeleteDonor={handleDeleteDonor}
          onAddDonorManual={handleAddDonorManual}
          onUpdateProgressReport={handleUpdateProgressReport}
          onDeleteProgressReport={handleDeleteProgressReport}
          onUpdateAllocation={handleUpdateAllocation}
          onDeleteAllocation={handleDeleteAllocation}
          onAddAllocation={handleAddAllocation}
          onUpdateDisbursement={handleUpdateDisbursement}
          onDeleteDisbursement={handleDeleteDisbursement}
          onUpdateGalleryItem={handleUpdateGalleryItem}
          onDeleteGalleryItem={handleDeleteGalleryItem}
          onUpdateProposal={handleUpdateProposal}
          onDeleteProposal={handleDeleteProposal}
          onUpdateSettings={handleUpdateSettings}
          onAddDonorPayment={handleAddDonorPayment}
          onUpdateDonorPayment={handleUpdateDonorPayment}
          onDeleteDonorPayment={handleDeleteDonorPayment}
        />
      ) : (
        <>
          {/* ==================================================== */}
          {/* VIEW A: BERANDA (HOME / SUMMARY STATS)              */}
          {/* ==================================================== */}
          {activeTab === 'beranda' && (
        <div className="flex-1 flex flex-col space-y-4 p-4 animate-fade-in select-none">
          {/* Welcome brand logo block */}
          <div className="bg-white rounded-3xl p-5 border border-sage/10 card-shadow flex flex-col items-center justify-center text-center space-y-3 relative overflow-hidden">
            <div className="absolute -top-10 -left-10 h-32 w-32 bg-sage/10 rounded-full filter blur-xl" />
            <div className="absolute -bottom-10 -right-10 h-32 w-32 bg-amber-500/5 rounded-full filter blur-xl" />
            
            <Logo className="h-16 shrink-0" showText={true} variant="light" />
            
            <div className="space-y-1 max-w-xs">
              <h3 className="serif font-bold text-sm text-deep tracking-tight mt-1">Perumahan Bumi Daya Indah <br /> Kec. Biringkanaya Kel. Sudiang Raya <br /> Kota Makassar</h3>
              <p className="text-[11px] text-slate-500 leading-normal">
                Sistem Akuntabilitas pembangunan Masjid An-Nur Perumahan Bumi Daya Indah Makassar.
              </p>
            </div>
          </div>

          {/* Core progression dashboard widgets */}
          <div className="grid grid-cols-2 gap-3.5">
            {/* Widget 1: Physical progress % */}
            <div className="bg-white border border-sage/10 rounded-2.5xl p-3.5 card-shadow flex flex-col justify-between space-y-2 relative">
              <div className="flex justify-between items-center">
                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">PROGRES FISIK</span>
                <span className="h-2 w-2 bg-olive rounded-full animate-pulse" />
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-extrabold font-mono text-deep leading-none">{physicalProgress.toFixed(1)}%</span>
                <span className="text-[10px] text-olive font-bold">Rampung</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-deep rounded-full" style={{ width: `${physicalProgress}%` }} />
              </div>
              <p className="text-[9.5px] text-slate-500 leading-tight">
                Tahap ornamen kubah utama & pengecoran dak mezzanine.
              </p>
            </div>

            {/* Widget 2: Funds progress % */}
            <div className="bg-white border border-sage/10 rounded-2.5xl p-3.5 card-shadow flex flex-col justify-between space-y-2 relative">
              <div className="flex justify-between items-center">
                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">CAPAIAN DANA</span>
                <Coins size={12} className="text-amber-500" />
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-extrabold font-mono text-amber-600 leading-none">
                  {((totalCollected / totalTarget) * 100).toFixed(1)}%
                </span>
                <span className="text-[9px] text-slate-400 font-bold">Terpenuhi</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-amber-400 rounded-full" style={{ width: `${(totalCollected / totalTarget) * 100}%` }} />
              </div>
              <p className="text-[9.5px] text-slate-505 leading-tight">
                Terkumpul <strong className="text-deep font-bold">{formattedRupiah(totalCollected)}</strong> dari target Rp 1.5M.
              </p>
            </div>
          </div>

          {/* Amal Jariyah quick redirection banner */}
          <div className="bg-gradient-to-br from-deep to-olive text-white rounded-[28px] p-4 card-shadow flex items-center justify-between gap-3 relative overflow-hidden">
            <div className="absolute right-0 bottom-0 opacity-15 translate-x-4 translate-y-4 scale-110 pointer-events-none">
              <Coins size={90} />
            </div>
            
            <div className="space-y-1 relative max-w-[210px]">
              <span className="text-[8.5px] font-bold text-amber-300 uppercase tracking-widest block">Model Pendanaan Terpadu</span>
              <h4 className="serif font-bold text-xs tracking-wide leading-tight">Mari Donasi Beramal Jariyah Sekarang</h4>
              <p className="text-[9.5px] text-cream opacity-90 leading-tight">
                Tersedia pilihan <strong>Iuran Bulanan</strong> beberapa tahun atau <strong>Donasi Sekali Bayar</strong> kebutuhan pembangunan.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('donasi')}
              id="quick-donate-beranda-btn"
              className="bg-amber-400 hover:bg-amber-500 text-slate-950 px-3.5 py-2.5 rounded-2xl text-[10.5px] font-bold cursor-pointer hover:shadow-md transition-all shrink-0 active:scale-95 flex items-center gap-1"
            >
              Wakaf
              <ArrowRight size={12} className="stroke-[2.5px]" />
            </button>
          </div>

          {/* Real-Time Live Feed Notification ticker */}
          <div className="bg-white border border-sage/10 card-shadow rounded-2xl p-2.5 flex items-center gap-2.5 text-[10.5px]">
            <div className="h-5 w-5 bg-deep/10 border border-deep/20 text-deep rounded-lg flex items-center justify-center font-bold text-xs">
              📢
            </div>
            <div className="flex-1 min-w-0">
              <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest block">Audit Feed Live</span>
              <p className="text-slate-650 truncate italic mt-0.5">
                {notifications[0]?.message || 'Laporan pembukuan masjid sinkronisasi amanah.'}
              </p>
            </div>
          </div>

          {/* Latest Daily progress logs carousel list */}
          <div className="space-y-2.5">
            <div className="flex justify-between items-baseline">
              <h4 className="serif font-bold text-[10px] text-deep uppercase tracking-wider">Laporan Progres Harian Terbaru</h4>
              <button
                onClick={() => setActiveTab('progres')}
                className="text-[10px] font-bold text-olive hover:text-deep flex items-center gap-0.5 cursor-pointer"
              >
                Selengkapnya
                <ArrowRight size={10} />
              </button>
            </div>

            <div className="space-y-3">
              {progressReports.slice(0, 2).map((report) => (
                <div
                  key={report.id}
                  onClick={() => setActiveTab('progres')}
                  className="bg-white border border-sage/10 text-left rounded-2.5xl p-3 flex gap-3 card-shadow cursor-pointer hover:shadow-xs transition-shadow"
                >
                  <img src={report.photoUrl} alt={report.title} className="h-16 w-20 object-cover rounded-xl border bg-slate-50 shrink-0" />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[8px] text-slate-400 select-none">
                        <span className="font-bold uppercase text-deep">{report.category}</span>
                        <span className="font-mono">{report.date}</span>
                      </div>
                      <h5 className="font-bold text-[10.5px] text-slate-800 mt-1 truncate leading-snug">{report.title}</h5>
                      <p className="text-[10px] text-slate-505 line-clamp-1 mt-0.5">{report.description}</p>
                    </div>
                    <div className="flex justify-between items-center text-[8.5px] text-slate-400 select-none mt-1">
                      <span>Kenaikan Progres: <strong className="text-olive font-mono">+{report.percentageAfter - report.percentageBefore}%</strong></span>
                      <strong className="text-slate-600 font-mono">Capaian: {report.percentageAfter}%</strong>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats physical parameters */}
          <div className="bg-white border border-sage/10 rounded-[26px] p-4 card-shadow space-y-3.5 select-none text-[11px] text-slate-600">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <strong className="serif font-extrabold text-deep text-[11.5px]">Kondisi Masjid Saat ini dan Spesifikasi</strong>
              <button
                type="button"
                onClick={() => setShowMoreSpecs(!showMoreSpecs)}
                className="text-[10px] text-teal-600 hover:text-teal-700 font-bold flex items-center gap-1 transition-all select-none cursor-pointer"
              >
                <span>Selengkapnya</span>
                <ArrowRight size={12} className={`transform transition-transform duration-300 ${showMoreSpecs ? 'rotate-90 text-teal-700' : ''}`} />
              </button>
            </div>
            
            {/* Image Slider of Old Mosque Photos */}
            <div className="relative rounded-2xl overflow-hidden h-40 bg-slate-50 border border-sage/5 group select-none">
              <img
                src={oldMosquePhotos[currentOldPhotoIndex].url}
                alt={oldMosquePhotos[currentOldPhotoIndex].label}
                className="w-full h-full object-cover transition-all duration-500"
              />
              {/* Navigation arrows overlay */}
              <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-2.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setCurrentOldPhotoIndex((prev) => (prev === 0 ? oldMosquePhotos.length - 1 : prev - 1));
                  }}
                  className="h-6 w-6 rounded-full bg-black/45 backdrop-blur-xs text-white flex items-center justify-center hover:bg-black/60 transition-colors select-none"
                >
                  ‹
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setCurrentOldPhotoIndex((prev) => (prev + 1) % oldMosquePhotos.length);
                  }}
                  className="h-6 w-6 rounded-full bg-black/45 backdrop-blur-xs text-white flex items-center justify-center hover:bg-black/60 transition-colors select-none"
                >
                  ›
                </button>
              </div>

              {/* Dots indicators overlay */}
              <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex gap-1 bg-black/20 backdrop-blur-xxs px-2 py-1 rounded-full">
                {oldMosquePhotos.map((_, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setCurrentOldPhotoIndex(idx)}
                    className={`h-1.5 w-1.5 rounded-full transition-all ${idx === currentOldPhotoIndex ? 'bg-white w-3' : 'bg-white/50'}`}
                  />
                ))}
              </div>

              {/* Bottom text overlay */}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-2.5 pt-6 text-left">
                <p className="text-[10px] text-white font-semibold leading-normal truncate">{oldMosquePhotos[currentOldPhotoIndex].label}</p>
                <span className="text-[8px] text-teal-300 block mt-0.5 uppercase tracking-wide font-black">Kondisi Fisik Masjid Saat Ini</span>
              </div>
            </div>

            {/* Click Expand details container */}
            {showMoreSpecs && (
              <div className="pt-2.5 border-t border-slate-100 space-y-3 text-left animate-fade-in select-none">
                {/* Expanded Spec Items */}
                <div className="bg-slate-50/80 p-3 rounded-2xl border border-sage/5 space-y-2.5 text-xs text-slate-700 leading-normal">
                  <div>
                    <span className="text-slate-400 block text-[8.5px] uppercase font-black tracking-wider">Identitas Kemanfaatan</span>
                    <strong className="text-slate-800 text-[10.5px] block mt-0.5 font-bold leading-normal">{mosqueSpecs.area}</strong>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 pt-2.5 border-t border-dashed border-slate-200">
                    <div>
                      <span className="text-slate-400 block text-[8.5px] uppercase font-black tracking-wider">Luas Tanah Induk</span>
                      <strong className="text-slate-800 text-[11px] block mt-0.5 font-mono font-bold">{mosqueSpecs.luasTanah} M²</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[8.5px] uppercase font-black tracking-wider">Luas Bangunan Ibadah</span>
                      <strong className="text-slate-800 text-[11px] block mt-0.5 font-mono font-bold">{mosqueSpecs.luasBangunan} M²</strong>
                    </div>
                  </div>

                  <div className="pt-2.5 border-t border-dashed border-slate-200 space-y-2">
                    <div>
                      <span className="text-slate-400 block text-[8.5px] uppercase font-black tracking-wider">Alamat Lengkap</span>
                      <p className="text-slate-700 text-[10px] mt-0.5 leading-relaxed font-semibold">{mosqueSpecs.alamat}</p>
                    </div>
                    <div className="pt-1.5 border-t border-slate-100">
                      <span className="text-slate-400 block text-[8.5px] uppercase font-black tracking-wider">Koordinat Peta</span>
                      <strong className="text-slate-800 text-[10px] block mt-0.5 font-mono font-bold">{mosqueSpecs.koordinat}</strong>
                    </div>
                  </div>
                </div>

                {/* Grid of detail photos at the bottom */}
                <div className="space-y-1.5">
                  <span className="text-slate-400 text-[8.5px] uppercase font-black tracking-wider block">Detail Foto-Foto Masjid Saat Ini (Sebelum Renov)</span>
                  <div className="grid grid-cols-2 gap-2">
                    {oldMosquePhotos.map((photo, i) => (
                      <div key={i} className="group relative rounded-xl overflow-hidden border border-slate-150 h-20 bg-slate-100">
                        <img 
                          src={photo.url} 
                          alt={photo.label} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent flex items-end p-1.5">
                          <span className="text-[7.5px] text-white leading-tight font-medium block truncate w-full">{photo.label}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* VIEW B: PROGRES HARIAN (DAILY LOGS / UPLOADING)      */}
      {/* ==================================================== */}
      {activeTab === 'progres' && (
        <ProgressTab
          progressReports={progressReports}
          onAddProgressReport={handleAddProgressReport}
        />
      )}

      {/* ==================================================== */}
      {/* VIEW C: DONASI / PENDANAAN CHANNELS                  */}
      {/* ==================================================== */}
      {activeTab === 'donasi' && (
        <DonationTab
          totalTarget={totalTarget}
          totalCollected={totalCollected}
          proposals={proposals}
          onAddDonation={handleAddDonation}
        />
      )}

      {/* ==================================================== */}
      {/* VIEW D: PROPOSAL DETAILS                             */}
      {/* ==================================================== */}
      {activeTab === 'proposal' && (
        <ProposalTab
          proposals={proposals}
          onSelectProposal={handleSelectProposalFromRAB}
        />
      )}

      {/* ==================================================== */}
      {/* VIEW F: PROFIL TRANSPARANSI / DASHBOARD DONATUR      */}
      {/* ==================================================== */}
      {activeTab === 'profil' && (
        <TransparencyTab
          donors={donors}
          allocations={allocations}
          disbursements={disbursements}
          totalTarget={totalTarget}
          totalCollected={totalCollected}
          totalSpent={totalSpent}
          onAddDisbursement={handleAddDisbursement}
          onAddDonorPayment={handleAddDonorPayment}
        />
      )}
        </>
      )}

      {/* 7. PANITIA SECURE LOGIN OVERLAY */}
      {showLoginModal && (
        <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-[340px] bg-white rounded-3xl overflow-hidden shadow-2xl border border-sage/20 p-5 space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1.5 text-deep">
                <Lock size={16} />
                <h3 className="font-extrabold text-[#344E41] uppercase text-xs tracking-wider">Amanah Pengelola</h3>
              </div>
              <button
                onClick={() => {
                  setShowLoginModal(false);
                  setLoginError(null);
                  setLoginPassword('');
                }}
                className="p-1 hover:bg-slate-100 rounded-full transition-colors text-slate-400 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="text-center space-y-1.5 py-1 select-none">
              <div className="h-10 w-10 bg-sage/10 text-deep border border-sage/20 rounded-full flex items-center justify-center mx-auto text-sm">
                🙏
              </div>
              <h4 className="font-bold text-xs text-slate-800 leading-tight">Sandi Akses Panitia</h4>
              <p className="text-[10px] text-slate-500 max-w-[240px] mx-auto text-center leading-normal">
                Verifikasi otoritas pengelola Masjid An-Nur Makassar. Masukkan sandi pimpinan.
              </p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-3">
              <div>
                <input
                  type="password"
                  required
                  autoFocus
                  placeholder="Password (sandbox: admin)"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full px-3 py-2 text-center text-xs border border-slate-200 focus:border-olive rounded-xl bg-[#FAF9F5] focus:outline-none placeholder-slate-400 font-mono tracking-widest text-[#344E41]"
                />
                {loginError && (
                  <p className="text-[9px] text-red-500 text-center font-bold mt-1.5 leading-snug">
                    {loginError}
                  </p>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowLoginModal(false);
                    setLoginError(null);
                    setLoginPassword('');
                  }}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-650 font-bold rounded-xl text-[11px] transition-colors cursor-pointer text-center"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  id="admin-login-submit-btn"
                  className="flex-1 py-2 bg-olive hover:bg-deep text-white font-black rounded-xl text-[11px] hover:shadow-md transition-all cursor-pointer text-center"
                >
                  Masuk ADM
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </MobileFrame>
  );
}
